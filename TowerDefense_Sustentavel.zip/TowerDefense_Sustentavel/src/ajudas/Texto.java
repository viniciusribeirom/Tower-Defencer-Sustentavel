package ajudas;

import org.newdawn.slick.TrueTypeFont;
import java.awt.Font;
import static org.lwjgl.opengl.GL11.*;

/**
 * Texto – Renderizador de Fontes TrueType via Slick2D.
 *
 * Responsabilidades:
 *  • Inicialização lazy de três tamanhos de fonte (pequena, normal, grande).
 *  • Renderização de strings com cor RGB customizável.
 *  • Preservação do estado OpenGL (blend/texture) para evitar side-effects.
 *
 * Design: Utilitário estático. Fontes são carregadas uma única vez.
 */
public final class Texto {
    private static TrueTypeFont fonteNormal;
    private static TrueTypeFont fonteGrande;
    private static TrueTypeFont fontePequena;
    private static boolean inicializado = false;

    private Texto() {}

    /** Inicializa as fontes AWT → Slick2D. Thread-safe via flag. */
    public static void init() {
        if (inicializado) return;
        Font awtNormal  = new Font("Arial", Font.BOLD, 20);
        Font awtGrande  = new Font("Arial", Font.BOLD, 48);
        Font awtPequena = new Font("Arial", Font.PLAIN, 14);
        fonteNormal  = new TrueTypeFont(awtNormal, true);
        fonteGrande  = new TrueTypeFont(awtGrande, true);
        fontePequena = new TrueTypeFont(awtPequena, true);
        inicializado = true;
    }

    public static void drawString(String texto, float x, float y) {
        drawString(texto, x, y, 1f, 1f, 1f);
    }

    public static void drawString(String texto, float x, float y, float r, float g, float b) {
        drawWithFont(fonteNormal, texto, x, y, r, g, b);
    }

    public static void drawStringBig(String texto, float x, float y, float r, float g, float b) {
        drawWithFont(fonteGrande, texto, x, y, r, g, b);
    }

    public static void drawStringSmall(String texto, float x, float y, float r, float g, float b) {
        drawWithFont(fontePequena, texto, x, y, r, g, b);
    }

    /** Renderiza preservando o estado GL_BLEND/GL_TEXTURE_2D anterior. */
    private static void drawWithFont(TrueTypeFont font, String texto, float x, float y, float r, float g, float b) {
        if (!inicializado) init();
        if (font == null || texto == null) return;

        boolean blendEnabled   = glIsEnabled(GL_BLEND);
        boolean textureEnabled = glIsEnabled(GL_TEXTURE_2D);

        glEnable(GL_TEXTURE_2D);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glColor4f(r, g, b, 1f);

        glPushMatrix();
        glLoadIdentity();
        font.drawString(x, y, texto);
        glPopMatrix();

        if (!blendEnabled)   glDisable(GL_BLEND);
        if (!textureEnabled) glDisable(GL_TEXTURE_2D);

        glColor4f(1f, 1f, 1f, 1f);
    }
}
