package ajudas;

import org.newdawn.slick.openal.Audio;
import org.newdawn.slick.openal.AudioLoader;
import org.newdawn.slick.util.ResourceLoader;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * AudioManager – Sistema de Áudio Centralizado.
 *
 * Responsabilidades:
 *  • Carregamento lazy-safe de efeitos sonoros (WAV/OGG).
 *  • Controle de volume global e mute.
 *  • Playback de música de fundo (loop) e one-shot SFX.
 *
 * Design: Singleton implícito via static methods. Trata falhas de OpenAL
 * de forma graceful (o jogo continua sem áudio se OpenAL falhar).
 */
public final class AudioManager {
    private static final Map<String, Audio> sons = new HashMap<>();
    private static float volumeGlobal = 1.0f;
    private static boolean mutado = false;
    private static boolean audioOK = false;
    private static Audio musicaAtual;
    private static String musicaAtualNome;

    private AudioManager() {} // utilitário

    /**
     * Inicializa o subsistema OpenAL e carrega todos os assets de som.
     * Se OpenAL não estiver disponível, o jogo prossegue em modo silencioso.
     */
    public static void init() {
        System.out.println("========================================");
        System.out.println("[AudioManager] Iniciando...");

        // Teste de existência do OpenAL
        try {
            Class.forName("org.lwjgl.openal.AL");
            org.lwjgl.openal.AL.create();
            audioOK = true;
            System.out.println("[AudioManager] OpenAL: OK");
        } catch (Throwable t) {
            audioOK = false;
            System.out.println("[AudioManager] OpenAL: FALHOU – " + t.getMessage());
            System.out.println("[AudioManager] O jogo prosseguirá sem áudio.");
            System.out.println("========================================");
            return;
        }

        // Efeitos sonoros do jogo
        carregar("tiro",       "sounds/tiro.wav");
        carregar("hit",        "sounds/hit.wav");
        carregar("morte",      "sounds/morte.wav");
        carregar("construir",  "sounds/construir.wav");
        carregar("vender",     "sounds/vender.wav");
        carregar("upgrade",    "sounds/upgrade.wav");
        carregar("dano_base",  "sounds/dano_base.wav");
        carregar("wave_start", "sounds/wave_start.wav");
        carregar("gameover",   "sounds/gameover.wav");
        carregar("click",      "sounds/click.wav");
        carregar("erro",       "sounds/erro.wav");

        System.out.println("[AudioManager] Sons carregados: " + sons.size() + "/11");
        System.out.println("========================================");
    }

    /** Tenta carregar um único asset no mapa interno. */
    private static void carregar(String nome, String path) {
        if (!audioOK) {
            System.out.println("[Audio] " + nome + " → Pulado (OpenAL falhou)");
            return;
        }
        try {
            InputStream in = ResourceLoader.getResourceAsStream("res/" + path);
            if (in == null) {
                System.out.println("[Audio] " + nome + " → ARQUIVO NÃO ENCONTRADO: res/" + path);
                return;
            }
            String ext = path.endsWith(".ogg") ? "OGG" : "WAV";
            Audio audio = AudioLoader.getAudio(ext, in);
            if (audio != null) {
                sons.put(nome, audio);
                System.out.println("[Audio] " + nome + " → OK");
            } else {
                System.out.println("[Audio] " + nome + " → AudioLoader retornou NULL");
            }
        } catch (Exception e) {
            System.out.println("[Audio] " + nome + " → ERRO: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    /** Reproduz efeito sonoro com pitch e volume customizáveis. */
    public static void play(String nome) { play(nome, 1.0f, 1.0f); }

    public static void play(String nome, float pitch, float vol) {
        if (!audioOK || mutado) return;
        try {
            Audio a = sons.get(nome);
            if (a != null) {
                a.playAsSoundEffect(pitch, vol * volumeGlobal, false);
            } else {
                // Log silenciado em release para não poluir console
                // System.out.println("[Audio] Tentou tocar '" + nome + "' mas não está carregado.");
            }
        } catch (Throwable t) {
            System.out.println("[Audio] Erro ao tocar '" + nome + "': " + t.getMessage());
        }
    }

    /** Inicia música de fundo em loop. Segura referência para poder parar depois. */
    public static void playMusica(String nome) {
        if (!audioOK || mutado) return;
        if (nome.equals(musicaAtualNome)) return;
        pararMusica();
        try {
            Audio a = sons.get(nome);
            if (a != null) {
                a.playAsMusic(1.0f, volumeGlobal * 0.6f, true);
                musicaAtual = a;
                musicaAtualNome = nome;
            }
        } catch (Throwable ignored) {}
    }

    public static void pararMusica() {
        if (!audioOK) return;
        try {
            if (musicaAtual != null) {
                musicaAtual.stop();
                musicaAtual = null;
                musicaAtualNome = null;
            }
        } catch (Throwable ignored) {}
    }

    public static void setVolume(float v) {
        volumeGlobal = Math.max(0f, Math.min(1f, v));
    }

    public static void toggleMute() {
        mutado = !mutado;
        if (mutado) pararMusica();
    }

    public static boolean isMutado() { return mutado; }

    /** Libera contexto OpenAL. Deve ser chamado antes de encerrar a aplicação. */
    public static void cleanup() {
        if (audioOK) {
            try {
                org.lwjgl.openal.AL.destroy();
            } catch (Throwable ignored) {}
        }
    }
}
