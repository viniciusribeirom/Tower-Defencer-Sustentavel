package ajudas;

import org.lwjgl.Sys;

/**
 * Clock – Gerenciador de Tempo e Delta Time.
 *
 * Responsabilidades:
 *  • Cálculo de delta time entre frames (em unidades lógicas).
 *  • Controle de pausa (congela o tempo de jogo).
 *  • Multiplicador de velocidade (fast-forward / slow-motion).
 *  • Total de tempo decorrido desde o reset.
 *
 * Design: Classe utilitária estática. Thread-safe para uso single-threaded do LWJGL.
 * O fator 0.03f na conversão de ms → unidades lógicas foi calibrado para que
 * 1 unidade ≈ 1 frame a 60 FPS.
 */
public final class Clock {
    private static boolean paused = false;
    public static long lastFrame, totalTime;
    public static float d = 0, multiplier = 1;

    private Clock() {}

    /** Retorna tempo atual do sistema em milissegundos (resolução LWJGL). */
    public static long getTime() {
        return Sys.getTime() * 1000 / Sys.getTimerResolution();
    }

    /**
     * Calcula delta bruto entre o frame atual e o anterior.
     * Limitado a 1.0f para evitar saltos enormes após lag spikes (clamp de segurança).
     */
    public static float getDelta() {
        long currentTime = getTime();
        int delta = (int) (currentTime - lastFrame);
        lastFrame = currentTime;
        float result = delta * 0.03f;
        return Math.min(result, 1.0f);
    }

    /** Delta time ajustado pelo multiplicador de velocidade e estado de pausa. */
    public static float Delta() {
        return paused ? 0f : d * multiplier;
    }

    public static float totalTime() { return totalTime; }
    public static float multiplier() { return multiplier; }

    /** Atualiza o relógio no início de cada frame (deve ser chamado uma única vez). */
    public static void update() {
        d = getDelta();
        totalTime += d;
    }

    /** Altera o multiplicador de velocidade em passos de +/-1, limitado ao intervalo [-1, 7]. */
    public static void ChangeMultiplier(int change) {
        if (multiplier + change >= -1 && multiplier + change <= 7) {
            multiplier += change;
        }
    }

    /** Alterna estado de pausa (toggle). */
    public static void Pause() {
        paused = !paused;
    }

    public static boolean isPaused() { return paused; }

    /** Reseta o relógio (usado ao iniciar nova partida). */
    public static void reset() {
        paused = false;
        lastFrame = getTime();
        d = 0;
        totalTime = 0;
    }
}
