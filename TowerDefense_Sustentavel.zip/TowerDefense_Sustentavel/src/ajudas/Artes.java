package ajudas;

import static org.lwjgl.opengl.GL11.*;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.lwjgl.LWJGLException;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.newdawn.slick.opengl.Texture;
import org.newdawn.slick.opengl.TextureLoader;
import org.newdawn.slick.util.ResourceLoader;

/**
 * Artes – Central de Renderização e Utilitários OpenGL.
 *
 * Responsabilidades:
 *  • Inicialização do contexto LWJGL (Display, GL states, viewport).
 *  • Normalização de coordenadas do mouse para o espaço lógico do jogo.
 *  • Primitivas de desenho imediato (quads, círculos, texturas rotacionadas).
 *  • Cache de texturas (evita recarregar PNGs do disco a cada frame).
 *
 * Design: Classe utilitária final. Não deve ser instanciada.
 */
public final class Artes {

    /** Resolução lógica interna do jogo (independente do tamanho da janela). */
    public static final int GAME_WIDTH = 1280;
    public static final int GAME_HEIGHT = 960;

    /** Resolução real da janela (pode diferir em multi-monitores / DPI scaling). */
    public static int WIDTH = GAME_WIDTH;
    public static int HEIGHT = GAME_HEIGHT;

    /** Cache de texturas em memória. Chave = nome do asset sem extensão. */
    private static final Map<String, Texture> textureCache = new HashMap<>();

    private Artes() {} // utilitário – não instanciar

    /**
     * Inicializa a sessão OpenGL.
     * Configura projeção ortográfica 2D, blending alpha, limpeza de tela e
     * criação do Display no modo de 1280×960.
     */
    public static void BeginSession() {
        Display.setTitle("Tower Defence Game JAVA – Refactored Edition");
        try {
            Display.setDisplayMode(new DisplayMode(GAME_WIDTH, GAME_HEIGHT));
            Display.create();
        } catch (LWJGLException e) {
            System.err.println("[Artes] Falha crítica ao criar Display LWJGL");
            e.printStackTrace();
            System.exit(1);
        }

        WIDTH = Display.getWidth();
        HEIGHT = Display.getHeight();

        glMatrixMode(GL_PROJECTION);
        glViewport(0, 0, WIDTH, HEIGHT);
        glLoadIdentity();
        glOrtho(0, GAME_WIDTH, GAME_HEIGHT, 0, 1, -1);
        glMatrixMode(GL_MODELVIEW);

        glClearColor(0.15f, 0.35f, 0.1f, 1.0f);
        glEnable(GL_TEXTURE_2D);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    }

    /** Converte coordenada X do mouse para o espaço lógico do jogo. */
    public static float getMouseX() {
        return Mouse.getX() * (float) GAME_WIDTH / WIDTH;
    }

    /** Converte coordenada Y do mouse (invertida pelo LWJGL) para espaço lógico. */
    public static float getMouseY() {
        return (HEIGHT - Mouse.getY()) * (float) GAME_HEIGHT / HEIGHT;
    }

    public static boolean isMouseLeftDown()  { return Mouse.isButtonDown(0); }
    public static boolean isMouseRightDown() { return Mouse.isButtonDown(1); }

    /** Cursor de debug – útil em desenvolvimento para alinhar hitboxes. */
    public static void drawDebugCursor() {
        float mx = getMouseX();
        float my = getMouseY();
        DrawQuadColor(mx - 4, my - 4, 8, 8, 1f, 0f, 0f, 0.8f);
        DrawQuadColor(mx - 1, my - 10, 2, 20, 1f, 0f, 0f, 0.5f);
        DrawQuadColor(mx - 10, my - 1, 20, 2, 1f, 0f, 0f, 0.5f);
    }

    /** Primitiva: quad preenchido sem textura. */
    public static void DrawQuad(float x, float y, float width, float height) {
        glBegin(GL_QUADS);
        glVertex2f(x, y);
        glVertex2f(x + width, y);
        glVertex2f(x + width, y + height);
        glVertex2f(x, y + height);
        glEnd();
    }

    /** Primitiva: quad texturizado (não rotacionado). */
    public static void DrawQuardTex(Texture tex, float x, float y, float width, float height) {
        if (tex == null) return;
        tex.bind();
        glTranslatef(x, y, 0);
        glBegin(GL_QUADS);
        glTexCoord2f(0, 0); glVertex2f(0, 0);
        glTexCoord2f(1, 0); glVertex2f(width, 0);
        glTexCoord2f(1, 1); glVertex2f(width, height);
        glTexCoord2f(0, 1); glVertex2f(0, height);
        glEnd();
        glLoadIdentity();
    }

    /** Primitiva: quad texturizado com rotação em graus (pivô no centro). */
    public static void DrawQuardTexRot(Texture tex, float x, float y, float width, float height, float angle) {
        if (tex == null) return;
        tex.bind();
        glTranslatef(x + width / 2, y + height / 2, 0);
        glRotatef(angle, 0, 0, 1);
        glTranslatef(-width / 2, -height / 2, 0);
        glBegin(GL_QUADS);
        glTexCoord2f(0, 0); glVertex2f(0, 0);
        glTexCoord2f(1, 0); glVertex2f(width, 0);
        glTexCoord2f(1, 1); glVertex2f(width, height);
        glTexCoord2f(0, 1); glVertex2f(0, height);
        glEnd();
        glLoadIdentity();
    }

    /** Primitiva: quad colorido com alpha (desabilita textura temporariamente). */
    public static void DrawQuadColor(float x, float y, float width, float height, float r, float g, float b, float a) {
        glPushAttrib(GL_ENABLE_BIT);
        glPushMatrix();
        glLoadIdentity();
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glDisable(GL_TEXTURE_2D);
        glColor4f(r, g, b, a);

        glBegin(GL_QUADS);
        glVertex2f(x, y);
        glVertex2f(x + width, y);
        glVertex2f(x + width, y + height);
        glVertex2f(x, y + height);
        glEnd();

        glColor4f(1f, 1f, 1f, 1f);
        glPopMatrix();
        glPopAttrib();
    }

    /** Primitiva: círculo em linha (wireframe). */
    public static void DrawCircle(float cx, float cy, float raio, float r, float g, float b, float a, int segmentos) {
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glColor4f(r, g, b, a);
        glBegin(GL_LINE_LOOP);
        for (int i = 0; i < segmentos; i++) {
            float theta = 2.0f * (float) Math.PI * i / segmentos;
            glVertex2f(raio * (float) Math.cos(theta) + cx, raio * (float) Math.sin(theta) + cy);
        }
        glEnd();
        glColor4f(1f, 1f, 1f, 1f);
        glDisable(GL_BLEND);
    }

    /** Primitiva: círculo preenchido (fan de triângulos). */
    public static void DrawCircleFilled(float cx, float cy, float raio, float r, float g, float b, float a, int segmentos) {
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glColor4f(r, g, b, a);
        glBegin(GL_TRIANGLE_FAN);
        glVertex2f(cx, cy);
        for (int i = 0; i <= segmentos; i++) {
            float theta = 2.0f * (float) Math.PI * i / segmentos;
            glVertex2f(raio * (float) Math.cos(theta) + cx, raio * (float) Math.sin(theta) + cy);
        }
        glEnd();
        glColor4f(1f, 1f, 1f, 1f);
        glDisable(GL_BLEND);
    }

    /** Carrega textura do classpath (res/). Não realiza cache. */
    public static Texture LoadTexture(String path, String fileType) {
        try (InputStream in = ResourceLoader.getResourceAsStream(path)) {
            if (in == null) {
                System.err.println("[Artes] Textura não encontrada: " + path);
                return null;
            }
            return TextureLoader.getTexture(fileType, in);
        } catch (IOException e) {
            System.err.println("[Artes] Erro IO ao carregar " + path + ": " + e.getMessage());
            return null;
        }
    }

    /**
     * Carrega textura via cache.
     * @param name nome do asset sem extensão (ex: "grama" → res/grama.png)
     */
    public static Texture QuickLoad(String name) {
        Texture cached = textureCache.get(name);
        if (cached != null) return cached;

        Texture tex = LoadTexture("res/" + name + ".png", "PNG");
        if (tex != null) textureCache.put(name, tex);
        return tex;
    }

    /** Limpa cache de texturas (útil ao trocar de estado ou liberar memória). */
    public static void clearTextureCache() {
        textureCache.clear();
    }
}
