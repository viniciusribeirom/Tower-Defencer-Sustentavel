package data.ui;

import static ajudas.Artes.*;

/**
 * UIManager – Primitivas visuais compartilhadas entre estados.
 *
 * Responsabilidades:
 *  • Desenhar painéis com bordas estilizadas.
 *  • Desenhar barras de progresso (vida, wave, cooldown).
 *
 * Design: Utilitário estático. Sem estado interno.
 */
public final class UIManager {
    private UIManager() {}

    public static void drawPanel(float x, float y, float w, float h, float alpha) {
        DrawQuadColor(x, y, w, h, 0.05f, 0.05f, 0.08f, alpha);
        DrawQuadColor(x, y, w, 2, 0.3f, 0.3f, 0.4f, alpha);
        DrawQuadColor(x, y + h - 2, w, 2, 0.1f, 0.1f, 0.15f, alpha);
        DrawQuadColor(x, y, 2, h, 0.3f, 0.3f, 0.4f, alpha);
        DrawQuadColor(x + w - 2, y, 2, h, 0.1f, 0.1f, 0.15f, alpha);
    }

    public static void drawProgressBar(float x, float y, float w, float h, float pct,
                                       float r, float g, float b, float rBg, float gBg, float bBg) {
        DrawQuadColor(x, y, w, h, rBg, gBg, bBg, 0.9f);
        if (pct > 0) {
            DrawQuadColor(x, y, w * Math.min(pct, 1f), h, r, g, b, 0.95f);
        }
    }
}
