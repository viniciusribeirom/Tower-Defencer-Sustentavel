package data.ui;

import ajudas.Artes;
import ajudas.AudioManager;
import ajudas.Texto;
import org.lwjgl.input.Mouse;

import static ajudas.Artes.*;

/**
 * Button – Componente de UI interativo.
 *
 * Responsabilidades:
 *  • Detecção de hover e clique com debounce (wasPressed).
 *  • Renderização visual com sombra, bordas e feedback de hover.
 *  • Emissão de SFX no clique.
 *
 * Design: POJO com listener funcional (ClickListener interface).
 * Não depende de estado global exceto posição do mouse.
 */
public class Button {
    public final float x, y, width, height;
    public final String text;
    private boolean hovered;
    private boolean wasPressed;
    private final ClickListener listener;

    public interface ClickListener {
        void onClick();
    }

    public Button(float x, float y, float width, float height, String text, ClickListener listener) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.text = text;
        this.listener = listener;
    }

    public void update() {
        float mx = Artes.getMouseX();
        float my = Artes.getMouseY();
        hovered = (mx >= x && mx <= x + width && my >= y && my <= y + height);

        boolean pressed = Mouse.isButtonDown(0);
        if (hovered && pressed && !wasPressed) {
            AudioManager.play("click", 1.0f, 0.6f);
            if (listener != null) listener.onClick();
        }
        wasPressed = pressed;
    }

    public void render() {
        // Sombra
        DrawQuadColor(x + 3, y + 3, width, height, 0f, 0f, 0f, 0.3f);

        // Corpo
        if (hovered) {
            DrawQuadColor(x, y, width, height, 0.25f, 0.55f, 0.25f, 0.9f);
            DrawQuadColor(x, y, width, 3, 0.4f, 0.9f, 0.4f, 1f);
        } else {
            DrawQuadColor(x, y, width, height, 0.15f, 0.35f, 0.15f, 0.85f);
            DrawQuadColor(x, y, width, 2, 0.3f, 0.7f, 0.3f, 0.8f);
        }

        // Bordas decorativas
        DrawQuadColor(x, y, width, 2, 0.1f, 0.2f, 0.1f, 0.5f);
        DrawQuadColor(x, y + height - 2, width, 2, 0.05f, 0.1f, 0.05f, 0.5f);

        // Texto centralizado
        float tw = text.length() * 11f;
        float tx = x + (width - tw) * 0.5f;
        float ty = y + (height - 20) * 0.5f + 2;
        float tr = hovered ? 1f : 0.85f;
        float tg = hovered ? 1f : 0.9f;
        float tb = hovered ? 0.8f : 0.7f;
        Texto.drawString(text, tx, ty, tr, tg, tb);
    }

    public boolean isHovered() { return hovered; }
}
