package data.effects;

import data.core.GameConfig;
import data.entities.Inimigo;
import data.enums.TipoDano;
import static ajudas.Clock.Delta;

/**
 * EfeitoStatus – Representa um efeito ativo sobre um inimigo (DOT, slow, etc).
 *
 * Responsabilidades:
 *  • Aplicar dano ao longo do tempo (Damage Over Time) para FOGO.
 *  • Aplicar/remover slow para GELO.
 *  • Decrescer duração e auto-remover quando expirar.
 *
 * Correções aplicadas:
 *  • Dano de FOGO agora acumula em float e só aplica quando ≥ 1.0, evitando
 *    truncamento para zero em frames rápidos (bug crítico do DOT inútil).
 *  • GELO aplica slow imediatamente e o remove ao expirar.
 *
 * Design: Cada instância está ligada a um inimigo-alvo. Não é reutilizável.
 */
public class EfeitoStatus {
    private final TipoDano tipo;
    private float duracaoRestante;
    private final float danoPorSegundo;
    private final float slowAplicado;
    private final Inimigo alvo;
    private float danoAcumulado = 0f; // acumulador fracionário (correção de precisão)

    public EfeitoStatus(TipoDano tipo, Inimigo alvo) {
        this.tipo = tipo;
        this.alvo = alvo;
        this.duracaoRestante = tipo.duracaoEfeito;

        if (tipo == TipoDano.FOGO) {
            this.danoPorSegundo = GameConfig.FIRE_DOT_DPS;
            this.slowAplicado = GameConfig.FIRE_SLOW_FACTOR;
        } else if (tipo == TipoDano.GELO) {
            this.danoPorSegundo = 0f;
            this.slowAplicado = tipo.slowFactor;
            alvo.aplicarSlow(slowAplicado);
        } else {
            this.danoPorSegundo = 0f;
            this.slowAplicado = 30f;
        }
    }

    /**
     * Atualiza o efeito por um frame.
     * @return true se o efeito ainda está ativo; false se expirou.
     */
    public boolean update() {
        duracaoRestante -= Delta();

        if (tipo == TipoDano.FOGO && danoPorSegundo > 0) {
            // Acumula dano fracionário para evitar perda por truncamento
            danoAcumulado += danoPorSegundo * Delta();
            if (danoAcumulado >= 1.0f) {
                int danoInt = (int) danoAcumulado;
                alvo.takeDamage(danoInt, TipoDano.FOGO);
                danoAcumulado -= danoInt;
            }
        }

        if (duracaoRestante <= -10) {
            if (tipo == TipoDano.GELO) {
                alvo.removerSlow();
            }
            return false; // efeito encerrado
        }
        return true;
    }

    public TipoDano getTipo() { return tipo; }
    public float getDuracaoRestante() { return duracaoRestante; }
}
