package data.save;

import java.io.Serializable;

/**
 * TowerData – DTO serializável para uma torre individual no savegame.
 *
 * Armazena posição no grid, tipo elementar e nível de upgrade.
 */
public class TowerData implements Serializable {
    private static final long serialVersionUID = 1L;

    public int tileX;
    public int tileY;
    public int tipoDanoOrdinal;
    public int nivel;

    public TowerData(int tileX, int tileY, int tipoDanoOrdinal, int nivel) {
        this.tileX = tileX;
        this.tileY = tileY;
        this.tipoDanoOrdinal = tipoDanoOrdinal;
        this.nivel = nivel;
    }
}
