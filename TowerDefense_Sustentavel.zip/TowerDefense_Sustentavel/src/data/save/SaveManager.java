package data.save;

import data.map.TileGrid;
import data.player.Jogador;
import data.towers.Torre;

import java.io.*;
import java.util.ArrayList;

/**
 * SaveManager – Persistência de savegames via serialização Java.
 *
 * Responsabilidades:
 *  • Salvar estado completo do jogo em arquivo binário.
 *  • Carregar e desserializar savegames.
 *  • Verificar existência de save.
 *  • Deletar save (new game).
 *
 * Design: Utilitário estático. Usa try-with-resources para evitar vazamento de streams.
 */
public final class SaveManager {
    private static final String SAVE_FILE = "savegame.dat";

    private SaveManager() {}

    public static boolean saveExists() {
        return new File(SAVE_FILE).exists();
    }

    public static void save(GameSnapshot snapshot) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(SAVE_FILE))) {
            oos.writeObject(snapshot);
        } catch (IOException e) {
            System.err.println("[SaveManager] Erro ao salvar: " + e.getMessage());
        }
    }

    public static GameSnapshot load() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(SAVE_FILE))) {
            return (GameSnapshot) ois.readObject();
        } catch (Exception e) {
            System.err.println("[SaveManager] Erro ao carregar save: " + e.getMessage());
            return null;
        }
    }

    public static void deleteSave() {
        new File(SAVE_FILE).delete();
    }

    /** Cria snapshot a partir do estado atual do jogo. */
    public static GameSnapshot createFromGame(TileGrid grid, Jogador jogador,
                                               ArrayList<Torre> torres, int wave) {
        GameSnapshot gs = new GameSnapshot();
        gs.wave = wave;
        gs.vida = jogador.getVida();
        gs.dinheiro = jogador.getDinheiro();
        gs.score = jogador.getScore();
        gs.inimigosMortos = jogador.getInimigosMortos();
        gs.tempoJogadoMs = jogador.getTempoSobrevividoMs();
        gs.dificuldade = "Normal";
        gs.mapTiles = grid.exportMap();
        for (Torre t : torres) {
            gs.towers.add(new TowerData(
                t.getStartTile().getXPlace(),
                t.getStartTile().getYPlace(),
                t.getTipoDano().ordinal(),
                t.getNivel()
            ));
        }
        return gs;
    }
}
