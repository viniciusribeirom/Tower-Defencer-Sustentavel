package data.save;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * GameSnapshot – DTO serializável para savegames.
 *
 * Responsabilidades:
 *  • Armazenar estado completo de uma partida em andamento.
 *  • Serialização Java nativa (ObjectOutputStream).
 *
 * Design: POJO puro, sem lógica de negócio. Versionado via serialVersionUID.
 */
public class GameSnapshot implements Serializable {
    private static final long serialVersionUID = 1L;

    public int wave;
    public int vida;
    public int dinheiro;
    public int score;
    public int inimigosMortos;
    public long tempoJogadoMs;
    public int[][] mapTiles;
    public ArrayList<TowerData> towers;
    public String dificuldade;

    public GameSnapshot() {
        towers = new ArrayList<>();
    }
}
