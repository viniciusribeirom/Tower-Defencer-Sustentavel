package data.core;

/**
 * GameConfig – Central de constantes e balanceamento do jogo.
 *
 * Design: Classe final utilitária. Alterar valores aqui afeta o balanceamento
 * global sem espalhar magic numbers pelo código.
 */
public final class GameConfig {
    private GameConfig() {}

    // === Resolução & Grid ===
    public static final int TILE_SIZE    = 64;
    public static final int GRID_WIDTH   = 20;
    public static final int GRID_HEIGHT  = 15;
    public static final int GAME_WIDTH   = 1280;
    public static final int GAME_HEIGHT  = 960;

    // === Jogador ===
    public static final int PLAYER_START_LIFE  = 20;
    public static final int PLAYER_START_MONEY = 150;

    // === Waves ===
    public static final float WAVE_INTERVAL_BASE = 150f; // tempo entre ondas (unidades lógicas)
    public static final float SPAWN_TIME_BASE    = 100f; // intervalo entre spawns

    // === Torres ===
    public static final int   TOWER_MAX_LEVEL           = 3;
    public static final int   TOWER_COST_BASE           = 50;
    public static final int   TOWER_COST_ELETRICO       = 75;
    public static final float TOWER_UPGRADE_DAMAGE_MULT   = 0.30f;
    public static final float TOWER_UPGRADE_RANGE_MULT    = 0.15f;
    public static final float TOWER_UPGRADE_COOLDOWN_MULT = 0.10f;
    public static final float TOWER_UPGRADE_COST_BASE     = 40;
    public static final float TOWER_UPGRADE_COST_STEP     = 30;

    // === Efeitos ===
    public static final float FIRE_DOT_DPS      = 2f;
    public static final float FIRE_SLOW_FACTOR    = 0.20f; // leve slow de fogo
    public static final float ICE_SLOW_FACTOR     = 30f;
    public static final float ICE_DURATION        = -10f;
    public static final float FIRE_DURATION       = 2f;

    // === Pathfinding ===
    public static final int   PATH_MAX_CHECKPOINTS = 50; // limite de segurança
}
