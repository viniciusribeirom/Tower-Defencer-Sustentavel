package data.core;

import org.newdawn.slick.opengl.Texture;
import static ajudas.Artes.*;

/**
 * Entity – Classe abstrata base para todas as entidades renderizáveis do jogo.
 *
 * Aplicação dos pilares da POO:
 *  • ABSTRAÇÃO: define o contrato update() e draw() que todas as entidades devem cumprir.
 *  • ENCAPSULAMENTO: posição, dimensões e estado de vida são protegidos, com acesso controlado.
 *  • HERANÇA: Inimigo, Torre, Projetil e Particula estendem esta classe.
 *  • POLIMORFISMO: coleções de Entity podem ser atualizadas/renderizadas uniformemente.
 *
 * Responsabilidades:
 *  • Armazenar transformação espacial (x, y, width, height).
 *  • Gerenciar estado de vida (alive).
 *  • Fornecer utilitários de colisão AABB e coordenadas de centro.
 */
public abstract class Entity {
    protected float x, y;
    protected float width, height;
    protected Texture texture;
    protected boolean alive;

    public Entity(float x, float y, float width, float height, Texture texture) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.texture = texture;
        this.alive = true;
    }

    /** Atualização lógica (movimento, timers, IA, etc). */
    public abstract void update();

    /** Renderização padrão via textura. Subclasses podem sobrescrever para efeitos customizados. */
    public void draw() {
        if (texture != null && alive) {
            DrawQuardTex(texture, x, y, width, height);
        }
    }

    // ---- Getters / Setters (encapsulamento) ----
    public float getX() { return x; }
    public void setX(float x) { this.x = x; }
    public float getY() { return y; }
    public void setY(float y) { this.y = y; }
    public float getWidth() { return width; }
    public void setWidth(float w) { this.width = w; }
    public float getHeight() { return height; }
    public void setHeight(float h) { this.height = h; }
    public boolean isAlive() { return alive; }
    public void setAlive(boolean alive) { this.alive = alive; }
    public Texture getTexture() { return texture; }
    public void setTexture(Texture texture) { this.texture = texture; }

    public float getCenterX() { return x + width * 0.5f; }
    public float getCenterY() { return y + height * 0.5f; }

    /** Retorna retângulo de colisão AABB desta entidade. */
    public Rectangle getBounds() {
        return new Rectangle(x, y, width, height);
    }

    /** Teste AABB de interseção com outra Entity. */
    public boolean intersects(Entity other) {
        return this.x < other.x + other.width  &&
               this.x + this.width > other.x    &&
               this.y < other.y + other.height  &&
               this.y + this.height > other.y;
    }

    /** Classe utilitária interna para representar retângulo de colisão. */
    public static class Rectangle {
        public final float x, y, width, height;
        public Rectangle(float x, float y, float width, float height) {
            this.x = x; this.y = y; this.width = width; this.height = height;
        }
        public boolean intersects(Rectangle r) {
            return this.x < r.x + r.width && this.x + this.width > r.x &&
                   this.y < r.y + r.height && this.y + this.height > r.y;
        }
    }
}
