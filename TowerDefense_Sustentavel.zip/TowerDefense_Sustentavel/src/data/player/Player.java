package data.player;

import data.core.GameConfig;
import data.entities.Inimigo;
import data.entities.Particula;
import data.enums.TipoDano;
import data.map.Tile;
import data.map.TileGrid;
import data.map.tileType;
import data.towers.Torre;
import data.towers.TowerFactory;
import ajudas.Artes;
import ajudas.AudioManager;
import ajudas.Texto;
import org.lwjgl.input.Keyboard;
import org.newdawn.slick.opengl.Texture;

import java.util.ArrayList;
import java.util.Iterator;

import static ajudas.Artes.*;
import static org.lwjgl.opengl.GL11.*;

/**
 * Player – Controlador de input do jogador e sistema de construção.
 *
 * Responsabilidades:
 *  • Leitura de mouse e teclado para interação com o mapa.
 *  • Modo de construção (build mode): preview de torre, alcance, validação.
 *  • Venda de torres (RMB), upgrade (U), seleção de tipo (1/2/3/C).
 *  • Emissão de partículas de feedback (poof verde, dourado).
 *
 * Design: Separação clara entre input (esta classe) e lógica de jogo (PlayState).
 * Não renderiza o HUD (responsabilidade do PlayState).
 */
public class Player {
    private final TileGrid grid;
    private tileType[] types;
    private int index;

    private boolean modoBuild;
    private TipoDano tipoTorreSelecionada;
    private boolean mouseRightWasDown = false;
    private final ArrayList<Particula> particulas = new ArrayList<>();

    public Player(TileGrid grid) {
        this.grid = grid;
        this.types = new tileType[]{tileType.Grama, tileType.Terra, tileType.Arvore};
        this.index = 0;
        this.modoBuild = false;
        this.tipoTorreSelecionada = TipoDano.NORMAL;
    }

    public void update(ArrayList<Torre> torres, Jogador jogador) {
        // Atualiza partículas
        Iterator<Particula> itp = particulas.iterator();
        while (itp.hasNext()) {
            if (!itp.next().isAlive()) itp.remove();
        }

        // Modo edição de tile (não-build)
        if (!modoBuild && Artes.isMouseLeftDown() && !Artes.isMouseRightDown()) {
            setTile();
        }

        // RMB: toggle build mode ou vender torre
        boolean mouseRightDown = Artes.isMouseRightDown();
        if (mouseRightDown && !mouseRightWasDown) {
            if (modoBuild) {
                modoBuild = false;
            } else {
                Torre t = getTorreSobMouse(torres);
                if (t != null) {
                    int reembolso = t.getCustoVenda();
                    jogador.ganharDinheiro(reembolso);
                    for (int p = 0; p < 12; p++) {
                        particulas.add(Particula.poofDourado(t.getCenterX(), t.getCenterY()));
                    }
                    AudioManager.play("vender", 1.0f, 0.8f);
                    torres.remove(t);
                    grid.SetTile(t.getStartTile().getXPlace(), t.getStartTile().getYPlace(), tileType.Grama);
                }
            }
        }
        mouseRightWasDown = mouseRightDown;

        // Teclado
        while (Keyboard.next()) {
            if (Keyboard.getEventKeyState()) {
                int key = Keyboard.getEventKey();
                if (key == Keyboard.KEY_RIGHT) moveIndex();
                if (key == Keyboard.KEY_1) { tipoTorreSelecionada = TipoDano.FOGO; modoBuild = true; }
                if (key == Keyboard.KEY_2) { tipoTorreSelecionada = TipoDano.GELO; modoBuild = true; }
                if (key == Keyboard.KEY_3) { tipoTorreSelecionada = TipoDano.ELETRICO; modoBuild = true; }
                if (key == Keyboard.KEY_C) { tipoTorreSelecionada = TipoDano.NORMAL; modoBuild = true; }
                if (key == Keyboard.KEY_ESCAPE) modoBuild = false;
                if (key == Keyboard.KEY_U) {
                    if (!modoBuild) {
                        Torre t = getTorreSobMouse(torres);
                        if (t != null) t.upgrade(jogador);
                    }
                }
            }
        }
    }

    public Torre getTorreSobMouse(ArrayList<Torre> torres) {
        int mx = getMouseGridX();
        int my = getMouseGridY();
        if (!isGridValid(mx, my)) return null;
        for (Torre t : torres) {
            if (t.getStartTile().getXPlace() == mx && t.getStartTile().getYPlace() == my) return t;
        }
        return null;
    }

    public void drawPreview(ArrayList<Torre> torresExistentes, ArrayList<Inimigo> inimigos) {
        if (modoBuild) drawBuildPreview(torresExistentes, inimigos);
        else drawTorreHover(torresExistentes, inimigos);
        for (Particula p : particulas) p.draw();
    }

    private void drawBuildPreview(ArrayList<Torre> torresExistentes, ArrayList<Inimigo> inimigos) {
        int mx = getMouseGridX();
        int my = getMouseGridY();
        if (!isGridValid(mx, my)) return;

        Tile t = grid.GetTile(mx, my);
        boolean podeConstruir = t.getType().buildable && !isTorreNoTile(mx, my, torresExistentes);

        // Preview com imagem da torre (translúcida)
        if (podeConstruir) {
            String previewImg = TowerFactory.getImageName(tipoTorreSelecionada);
            Texture tex = QuickLoad(previewImg);
            if (tex != null) {
                glEnable(GL_BLEND);
                glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
                glColor4f(1f, 1f, 1f, 0.6f);
                DrawQuardTex(tex, t.getX(), t.getY(), 64, 64);
                glColor4f(1f, 1f, 1f, 1f);
                glDisable(GL_BLEND);
            }
        }

        // Overlay de validação (verde/vermelho)
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glColor4f(podeConstruir ? 0f : 1f, podeConstruir ? 1f : 0f, 0f, 0.2f);
        DrawQuad(t.getX(), t.getY(), 64, 64);
        glColor4f(1f, 1f, 1f, 1f);
        glDisable(GL_BLEND);

        // Alcance de construção
        if (podeConstruir) {
            float cx = t.getCenterX();
            float cy = t.getCenterY();
            float alcance = TowerFactory.getAlcancePreview(tipoTorreSelecionada);
            float[] cor = getCorPreview(tipoTorreSelecionada);
            DrawCircleFilled(cx, cy, alcance, cor[0], cor[1], cor[2], 0.08f, 32);
            DrawCircle(cx, cy, alcance, cor[0], cor[1], cor[2], 0.25f, 32);
        }
    }

    private void drawTorreHover(ArrayList<Torre> torres, ArrayList<Inimigo> inimigos) {
        Torre t = getTorreSobMouse(torres);
        if (t == null) return;

        float cx = t.getCenterX();
        float cy = t.getCenterY();
        float[] cor = getCorPreview(t.getTipoDano());

        DrawCircleFilled(cx, cy, t.getAlcance(), cor[0], cor[1], cor[2], 0.08f, 32);
        DrawCircle(cx, cy, t.getAlcance(), cor[0], cor[1], cor[2], 0.25f, 32);

        // Painel de info
        float infoX = t.getX() + 70;
        float infoY = t.getY() - 10;
        if (infoX > GameConfig.GAME_WIDTH - 200) infoX = t.getX() - 210;

        DrawQuadColor(infoX, infoY, 190, 110, 0.05f, 0.05f, 0.08f, 0.9f);
        DrawQuadColor(infoX, infoY, 190, 2, cor[0], cor[1], cor[2], 0.9f);

        String tipoNome = t.getTipoDano().nome;
        Texto.drawString("Torre " + tipoNome, infoX + 8, infoY + 6, cor[0], cor[1], cor[2]);
        Texto.drawString("Nivel: " + t.getNivel() + "/" + GameConfig.TOWER_MAX_LEVEL, infoX + 8, infoY + 26, 1f, 1f, 1f);
        Texto.drawString("Dano: " + t.getDamage(), infoX + 8, infoY + 44, 0.8f, 0.8f, 0.8f);
        Texto.drawString("Alcance: " + (int) t.getAlcance(), infoX + 8, infoY + 60, 0.8f, 0.8f, 0.8f);
        Texto.drawString("Cooldown: " + String.format("%.1f", t.getCooldown()) + "s", infoX + 8, infoY + 76, 0.8f, 0.8f, 0.8f);

        if (t.getNivel() < GameConfig.TOWER_MAX_LEVEL) {
            Texto.drawString("U: Upgrade ($" + t.getCustoUpgrade() + ")", infoX + 8, infoY + 94, 1f, 0.85f, 0.1f);
        } else {
            Texto.drawString("MAX LEVEL", infoX + 8, infoY + 94, 0.5f, 0.5f, 0.5f);
        }
    }

    private float[] getCorPreview(TipoDano tipo) {
        if (tipo == TipoDano.FOGO)      return new float[]{1f, 0.3f, 0.1f};
        if (tipo == TipoDano.GELO)       return new float[]{0.2f, 0.6f, 1f};
        if (tipo == TipoDano.ELETRICO)   return new float[]{0.9f, 0.8f, 0.1f};
        return new float[]{0.2f, 1f, 0.2f};
    }

    /**
     * Tenta construir uma torre no tile sob o mouse.
     * @return a nova Torre se construída com sucesso; null caso contrário.
     */
    public Torre tentarConstruir(ArrayList<Torre> torresExistentes, Jogador jogador) {
        if (!modoBuild || !Artes.isMouseLeftDown()) return null;

        int mx = getMouseGridX();
        int my = getMouseGridY();
        if (!isGridValid(mx, my)) return null;

        Tile t = grid.GetTile(mx, my);
        if (!t.getType().buildable) return null;
        if (isTorreNoTile(mx, my, torresExistentes)) return null;

        int custo = (tipoTorreSelecionada == TipoDano.ELETRICO) ? GameConfig.TOWER_COST_ELETRICO : GameConfig.TOWER_COST_BASE;
        if (!jogador.gastar(custo)) {
            AudioManager.play("erro", 1.5f, 0.4f);
            return null;
        }

        grid.SetTile(mx, my, tileType.Arvore);
        for (int p = 0; p < 15; p++) {
            particulas.add(Particula.poofVerde(t.getCenterX(), t.getCenterY()));
        }
        AudioManager.play("construir", 1.0f, 0.7f);
        return TowerFactory.create(tipoTorreSelecionada, t);
    }

    private boolean isTorreNoTile(int x, int y, ArrayList<Torre> torres) {
        for (Torre torre : torres) {
            if (torre.getStartTile().getXPlace() == x && torre.getStartTile().getYPlace() == y) return true;
        }
        return false;
    }

    private int getMouseGridX() { return (int) (Artes.getMouseX() / GameConfig.TILE_SIZE); }
    private int getMouseGridY() { return (int) (Artes.getMouseY() / GameConfig.TILE_SIZE); }
    private boolean isGridValid(int x, int y) {
        return x >= 0 && x < GameConfig.GRID_WIDTH && y >= 0 && y < GameConfig.GRID_HEIGHT;
    }

    private void setTile() {
        int x = getMouseGridX();
        int y = getMouseGridY();
        if (isGridValid(x, y)) {
            grid.SetTile(x, y, types[index]);
        }
    }

    private void moveIndex() {
        index = (index + 1) % types.length;
    }

    // ---- Getters ----
    public tileType getSelectedType() { return types[index]; }
    public boolean isModoBuild() { return modoBuild; }
    public TipoDano getTipoTorreSelecionada() { return tipoTorreSelecionada; }
}
