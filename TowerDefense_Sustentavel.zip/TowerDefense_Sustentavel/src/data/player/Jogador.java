package data.player;

/**
 * Jogador – Modelo de dados do estado do jogador.
 *
 * Responsabilidades:
 *  • Vida, dinheiro, pontuação, contagem de abates e tempo de sobrevivência.
 *  • Transações econômicas (ganhar/gastar) com validação.
 *  • Detecção de game over.
 *
 * Design: POJO encapsulado. Não contém lógica de renderização (SRP).
 * Thread-safe para uso single-threaded do game loop.
 */
public class Jogador {
    private int vida;
    private int dinheiro;
    private boolean gameOver;
    private int score;
    private int inimigosMortos;
    private long tempoInicio;

    /** Construtor para nova partida. */
    public Jogador(int vidaInicial, int dinheiroInicial) {
        this.vida = vidaInicial;
        this.dinheiro = dinheiroInicial;
        this.gameOver = false;
        this.score = 0;
        this.inimigosMortos = 0;
        this.tempoInicio = System.currentTimeMillis();
    }

    /** Construtor para load de savegame (preserva tempo decorrido). */
    public Jogador(int vida, int dinheiro, int score, int kills, long tempoInicio) {
        this.vida = vida;
        this.dinheiro = dinheiro;
        this.score = score;
        this.inimigosMortos = kills;
        this.tempoInicio = tempoInicio;
        this.gameOver = false;
    }

    public void ganharDinheiro(int valor) {
        dinheiro += valor;
    }

    /**
     * Tenta gastar dinheiro.
     * @return true se a transação foi autorizada (saldo suficiente).
     */
    public boolean gastar(int valor) {
        if (dinheiro >= valor) {
            dinheiro -= valor;
            return true;
        }
        return false;
    }

    public void perderVida(int dano) {
        vida -= dano;
        if (vida <= 0) {
            vida = 0;
            gameOver = true;
        }
    }

    public void adicionarScore(int pts) { score += pts; }
    public void registrarKill() { inimigosMortos++; }

    // ---- Getters / Setters ----
    public int getVida() { return vida; }
    public int getDinheiro() { return dinheiro; }
    public boolean isGameOver() { return gameOver; }
    public int getScore() { return score; }
    public int getInimigosMortos() { return inimigosMortos; }
    public long getTempoSobrevividoMs() { return System.currentTimeMillis() - tempoInicio; }
    public void setGameOver(boolean b) { gameOver = b; }
}
