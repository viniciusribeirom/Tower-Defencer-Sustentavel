package data.score;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * ScoreManager – Persistência e ranking de high scores.
 *
 * Responsabilidades:
 *  • Adicionar novas pontuações ao arquivo "highscores.txt".
 *  • Carregar, ordenar (decrescente por score) e exibir top 10.
 *
 * Formato de linha: nome;wave;tempoMs;score;kills
 *
 * Design: Utilitário estático. Thread-safe para uso single-threaded.
 */
public final class ScoreManager {
    private static final String FILE = "highscores.txt";

    private ScoreManager() {}

    public static class ScoreEntry {
        public final String nome;
        public final int wave;
        public final long tempoMs;
        public final int score;
        public final int kills;

        public ScoreEntry(String nome, int wave, long tempoMs, int score, int kills) {
            this.nome = nome;
            this.wave = wave;
            this.tempoMs = tempoMs;
            this.score = score;
            this.kills = kills;
        }

        public String formatTempo() {
            int seg = (int) (tempoMs / 1000) % 60;
            int min = (int) (tempoMs / 60000);
            return String.format("%02d:%02d", min, seg);
        }
    }

    public static void addScore(String nome, int wave, long tempoMs, int score, int kills) {
        try (PrintWriter out = new PrintWriter(new FileWriter(FILE, true))) {
            out.println(nome + ";" + wave + ";" + tempoMs + ";" + score + ";" + kills);
        } catch (IOException e) {
            System.err.println("[ScoreManager] Erro ao salvar score: " + e.getMessage());
        }
    }

    public static ArrayList<ScoreEntry> loadScores() {
        ArrayList<ScoreEntry> list = new ArrayList<>();
        File f = new File(FILE);
        if (!f.exists()) return list;

        try (BufferedReader br = new BufferedReader(new FileReader(FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = line.split(";");
                if (p.length == 5) {
                    try {
                        list.add(new ScoreEntry(p[0], Integer.parseInt(p[1]),
                                 Long.parseLong(p[2]), Integer.parseInt(p[3]), Integer.parseInt(p[4])));
                    } catch (NumberFormatException ignored) {}
                }
            }
        } catch (IOException e) {
            System.err.println("[ScoreManager] Erro ao carregar scores: " + e.getMessage());
        }

        Collections.sort(list, new Comparator<ScoreEntry>() {
            public int compare(ScoreEntry a, ScoreEntry b) {
                return Integer.compare(b.score, a.score);
            }
        });
        return list;
    }
}
