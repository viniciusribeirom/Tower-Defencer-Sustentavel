package data.enums;

/**
 * TipoDano – Enum que define os elementos / tipos de dano das torres.
 *
 * Responsabilidades:
 *  • Armazenar multiplicadores de dano, slow e duração de efeito por elemento.
 *  • Servir como "tipo" tanto para torres quanto para projéteis.
 *
 * Design: Enum rico (rich enum) com campos de balanceamento. Facilita a adição
 * de novos elementos (Veneno, Arcano, etc.) sem alterar lógica de negócio.
 */
public enum TipoDano {
    NORMAL  ("Normal",   1.0f, 0.0f, 0.0f),
    FOGO    ("Fogo",     1.2f, 0.2f, 3.0f),   // +20% dano, leve slow, DOT 3s
    GELO    ("Gelo",     0.7f, 0.5f, 2.0f),   // -30% dano, slow 50% por 2s
    ELETRICO("Eletrico", 0.9f, 0.0f, 0.0f);   // -10% dano, chain lightning (lógica especial)

    public final String nome;
    public final float multiplicadorDano;
    public final float slowFactor;     // 0 = sem slow, 0.5 = 50% redução de velocidade
    public final float duracaoEfeito;  // segundos (unidades lógicas aproximadas)

    TipoDano(String nome, float multiplicadorDano, float slowFactor, float duracaoEfeito) {
        this.nome = nome;
        this.multiplicadorDano = multiplicadorDano;
        this.slowFactor = slowFactor;
        this.duracaoEfeito = duracaoEfeito;
    }
}
