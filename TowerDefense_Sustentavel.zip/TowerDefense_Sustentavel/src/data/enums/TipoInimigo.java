package data.enums;

/**
 * TipoInimigo – Enum que define as classes de inimigos (slimes).
 *
 * Responsabilidades:
 *  • Armazenar atributos base (vida, velocidade, recompensa).
 *  • Multiplicador de onda para escalonamento de dificuldade.
 *  • Associação com asset gráfico (textureName).
 *
 * Design: Rich enum. Balanceamento centralizado. Adicionar novos tipos é trivial.
 */
public enum TipoInimigo {
    VERDE  ("Slime Verde",   110, 5.0f, 10, 1.0f, 0x00FF00, "inimigo_verde"),
    VERMELHO("Slime Vermelho", 90, 8.0f, 18, 0.8f, 0xFF0000, "inimigo_vermelho"),
    AZUL   ("Slime Tank",     280, 4.2f, 28, 1.5f, 0x0088FF, "inimigo_azul"),
    BOSS   ("Slime Boss",     900, 2.8f, 100, 3.0f, 0x8800FF, "inimigo_boss");

    public final String nome;
    public final int vidaBase;
    public final float speedBase;
    public final int recompensa;
    public final float multiplicadorOnda; // fator de escala de vida/speed por onda
    public final int corHex;
    public final String textureName;

    TipoInimigo(String nome, int vidaBase, float speedBase, int recompensa,
                float multiplicadorOnda, int corHex, String textureName) {
        this.nome = nome;
        this.vidaBase = vidaBase;
        this.speedBase = speedBase;
        this.recompensa = recompensa;
        this.multiplicadorOnda = multiplicadorOnda;
        this.corHex = corHex;
        this.textureName = textureName;
    }
}
