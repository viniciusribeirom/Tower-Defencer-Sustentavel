package data.states;

/**
 * State – Classe abstrata base para todos os estados do jogo.
 *
 * Pilares da POO:
 *  • ABSTRAÇÃO: define o ciclo de vida comum (init, update, render, enter, exit).
 *  • HERANÇA: MenuState, PlayState, PauseState, GameOverState estendem esta classe.
 *  • POLIMORFISMO: StateManager manipula estados genericamente via referência State.
 *
 * Design: Template Method. Cada estado implementa seu próprio comportamento.
 */
public abstract class State {
    protected final StateManager sm;

    public State(StateManager sm) {
        this.sm = sm;
    }

    /** Chamado uma única vez quando o estado é empilhado. */
    public abstract void init();

    /** Lógica de atualização (input, IA, timers). */
    public abstract void update();

    /** Renderização (OpenGL). */
    public abstract void render();

    /** Chamado quando o estado volta ao topo da pilha (após pop). */
    public abstract void enter();

    /** Chamado quando o estado sai do topo da pilha (push ou pop). */
    public abstract void exit();
}
