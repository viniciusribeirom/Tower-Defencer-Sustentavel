package data.states;

import java.util.Stack;

/**
 * StateManager – Gerenciador de pilha de estados (Stack-based FSM).
 *
 * Responsabilidades:
 *  • Manter pilha de estados (Menu → Play → Pause → Play → GameOver → Menu).
 *  • Garantir callbacks enter()/exit() corretos durante transições.
 *  • Delegar update() e render() para o estado no topo.
 *
 * Design: Singleton thread-safe (inicialização lazy via init()).
 * Usa Stack<> para suportar overlays (Pause sobre Play).
 */
public class StateManager {
    private final Stack<State> states;
    private static StateManager instance;

    public static void init() {
        instance = new StateManager();
    }

    public static StateManager getInstance() {
        if (instance == null) init();
        return instance;
    }

    private StateManager() {
        states = new Stack<>();
    }

    public void push(State s) {
        if (!states.isEmpty()) states.peek().exit();
        states.push(s);
        s.init();
        s.enter();
    }

    public void pop() {
        if (!states.isEmpty()) {
            states.pop().exit();
            if (!states.isEmpty()) states.peek().enter();
        }
    }

    /** Substitui toda a pilha por um único estado (transição completa). */
    public void set(State s) {
        while (!states.isEmpty()) states.pop().exit();
        push(s);
    }

    public void update() {
        if (!states.isEmpty()) states.peek().update();
    }

    public void render() {
        if (!states.isEmpty()) states.peek().render();
    }
}
