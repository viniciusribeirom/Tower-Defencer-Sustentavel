package data.states;

import ajudas.Texto;
import ajudas.AudioManager;
import data.player.Jogador;
import data.score.ScoreManager;
import data.ui.Button;
import data.ui.UIManager;
import org.lwjgl.input.Keyboard;
import static ajudas.Artes.*;

/**
 * GameOverState – Tela de fim de jogo com estatísticas e save de score.
 *
 * Responsabilidades:
 *  • Exibir estatísticas finais (wave, score, kills, tempo, dinheiro).
 *  • Permitir input de nome para salvar no ranking.
 *  • Navegação para Retry, Menu ou Save Score.
 *
 * Design: Estado terminal (não overlay). Consome eventos de teclado para input de nome.
 */
public class GameOverState extends State {
    private final Jogador jogador;
    private final int wave;
    private float alpha;
    private boolean saving;
    private StringBuilder nome;
    private Button btnRetry, btnMenu, btnSaveScore;

    public GameOverState(StateManager sm, Jogador jogador, int wave) {
        super(sm);
        this.jogador = jogador;
        this.wave = wave;
		this.nome = new StringBuilder();
    }

    @Override
    public void init() {
        while (Keyboard.next()) {} // limpa buffer
        alpha = 0;
        saving = false;
        nome = new StringBuilder("Player");
        AudioManager.play("gameover", 1.0f, 1.0f);

        float bw = 220, bh = 42, bx = GAME_WIDTH / 2f - bw / 2f;
        btnRetry = new Button(bx, 420, bw, bh, "Retry", () -> sm.set(new PlayState(sm, false)));
        btnMenu = new Button(bx, 480, bw, bh, "Main Menu", () -> sm.set(new MenuState(sm)));
        btnSaveScore = new Button(bx, 540, bw, bh, "Save Score", () -> saving = true);
    }

    @Override public void enter() {}
    @Override public void exit() {}

    @Override
    public void update() {
        if (alpha < 0.85f) alpha += 0.015f;

        if (saving) {
            while (Keyboard.next()) {
                if (Keyboard.getEventKeyState()) {
                    char c = Keyboard.getEventCharacter();
                    int k = Keyboard.getEventKey();
                    if (k == Keyboard.KEY_RETURN) {
                        ScoreManager.addScore(nome.toString(), wave,
                            jogador.getTempoSobrevividoMs(), jogador.getScore(), jogador.getInimigosMortos());
                        saving = false;
                    } else if (k == Keyboard.KEY_BACK && nome.length() > 0) {
                        nome.deleteCharAt(nome.length() - 1);
                    } else if (c >= 32 && c < 127 && nome.length() < 12) {
                        nome.append(c);
                    }
                }
            }
        }
        btnRetry.update();
        btnMenu.update();
        btnSaveScore.update();
    }

    @Override
    public void render() {
        DrawQuadColor(0, 0, GAME_WIDTH, GAME_HEIGHT, 0.05f, 0f, 0f, alpha);
        float py = 120;
        Texto.drawStringBig("GAME OVER", GAME_WIDTH / 2f - 200, py, 1f, 0.15f, 0.15f);
        py += 90;
        UIManager.drawPanel(GAME_WIDTH / 2f - 220, py, 440, 260, 0.85f);

        Texto.drawString("Wave Reached: " + wave, GAME_WIDTH / 2f - 110, py + 20, 1f, 0.8f, 0.2f);
        Texto.drawString("Score: " + jogador.getScore(), GAME_WIDTH / 2f - 80, py + 55, 1f, 1f, 1f);
        Texto.drawString("Kills: " + jogador.getInimigosMortos(), GAME_WIDTH / 2f - 60, py + 85, 0.7f, 0.7f, 0.7f);

        long ms = jogador.getTempoSobrevividoMs();
        int seg = (int) (ms / 1000) % 60;
        int min = (int) (ms / 60000);
        Texto.drawString(String.format("Time: %02d:%02d", min, seg), GAME_WIDTH / 2f - 60, py + 115, 0.7f, 0.7f, 0.7f);
        Texto.drawString("Money: $" + jogador.getDinheiro(), GAME_WIDTH / 2f - 70, py + 145, 0.5f, 0.8f, 0.3f);

        if (saving) {
            Texto.drawString("Enter Name: " + nome.toString() + "_", GAME_WIDTH / 2f - 130, py + 190, 1f, 1f, 0.2f);
        } else {
            btnRetry.render();
            btnMenu.render();
            btnSaveScore.render();
        }
    }
}
