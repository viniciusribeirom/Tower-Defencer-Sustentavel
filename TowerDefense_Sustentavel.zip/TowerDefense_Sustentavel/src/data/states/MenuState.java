package data.states;

import ajudas.Artes;
import ajudas.AudioManager;
import ajudas.Texto;
import data.score.ScoreManager;
import data.ui.Button;
import data.ui.UIManager;
import static ajudas.Artes.*;

import java.util.ArrayList;
import java.util.Random;

/**
 * MenuState – Estado inicial do jogo (tela principal).
 *
 * Responsabilidades:
 *  • Exibir título animado, partículas de fundo e botões de navegação.
 *  • Transições para PlayState (novo jogo / continue), High Scores e Exit.
 *  • Reproduzir música de menu.
 *
 * Design: Estado autossuficiente. Partículas são puramente decorativas.
 */
public class MenuState extends State {
    private ArrayList<Button> buttons;
    private ArrayList<Particle> particles;
    private Random rand;
    private float titleY, titleDir;
    private boolean showHighScores;
    private ArrayList<ScoreManager.ScoreEntry> scores;

    private class Particle {
        float x, y, speed, size, alpha;
        Particle(float x, float y, float speed, float size) {
            this.x = x; this.y = y; this.speed = speed; this.size = size;
            this.alpha = 0.1f + rand.nextFloat() * 0.2f;
        }
        void update() {
            y += speed;
            if (y > HEIGHT) { y = -10; x = rand.nextInt(WIDTH); }
        }
        void render() {
            DrawQuadColor(x, y, size, size, 0.2f, 0.5f, 0.3f, alpha);
        }
    }

    public MenuState(StateManager sm) { super(sm); }

    @Override
    public void init() {
        rand = new Random();
        particles = new ArrayList<>();
        for (int i = 0; i < 50; i++) {
            particles.add(new Particle(rand.nextInt(WIDTH), rand.nextInt(HEIGHT),
                         0.2f + rand.nextFloat() * 0.5f, 2 + rand.nextFloat() * 4));
        }
        showHighScores = false;
        scores = new ArrayList<>();

        buttons = new ArrayList<>();
        float bw = 280, bh = 45, bx = WIDTH / 2f - bw / 2f;
        float startY = 320, gap = 60;

        buttons.add(new Button(bx, startY, bw, bh, "Start Game", () -> {
            sm.set(new PlayState(sm, false));
            AudioManager.pararMusica();
        }));
        buttons.add(new Button(bx, startY + gap, bw, bh, "Continue", () -> {
            if (data.save.SaveManager.saveExists()) sm.set(new PlayState(sm, true));
        }));
        buttons.add(new Button(bx, startY + gap * 2, bw, bh, "High Scores", () -> {
            showHighScores = true;
            scores = ScoreManager.loadScores();
        }));
        buttons.add(new Button(bx, startY + gap * 3, bw, bh, "Exit", () -> System.exit(0)));

        titleY = 120; titleDir = 0.3f;
        AudioManager.playMusica("musica_menu");
    }

    @Override public void enter() { showHighScores = false; }
    @Override public void exit() {}

    @Override
    public void update() {
        for (Particle p : particles) p.update();
        titleY += titleDir * 0.02f;
        if (titleY > 125 || titleY < 115) titleDir *= -1;
        if (!showHighScores) {
            for (Button b : buttons) b.update();
        }
    }

    @Override
    public void render() {
        DrawQuadColor(0, 0, GAME_WIDTH, GAME_HEIGHT, 0.02f, 0.04f, 0.03f, 1f);
        for (Particle p : particles) p.render();

        if (!showHighScores) {
            Texto.drawStringBig("CCG TOWER DEFENSE", GAME_WIDTH / 2f - 280, titleY, 0.2f, 0.9f, 0.4f);
            Texto.drawString("DEFEND THE REALM", GAME_WIDTH / 2f - 100, titleY + 60, 0.4f, 0.7f, 0.4f);
            for (Button b : buttons) b.render();

            if (buttons.get(1).isHovered() && !data.save.SaveManager.saveExists()) {
                Texto.drawStringSmall("No save file found", buttons.get(1).x + buttons.get(1).width + 10,
                                      buttons.get(1).y + 15, 0.8f, 0.2f, 0.2f);
            }
            Texto.drawStringSmall("v2.0 – Refactored Java LWJGL Edition", 10, GAME_HEIGHT - 20, 0.3f, 0.3f, 0.3f);
        } else {
            renderHighScores();
        }
        // Artes.drawDebugCursor(); // debug de mouse
    }

    private void renderHighScores() {
        UIManager.drawPanel(WIDTH / 2f - 250, 150, 500, 500, 0.9f);
        Texto.drawStringBig("HIGH SCORES", WIDTH / 2f - 160, 170, 1f, 0.85f, 0.1f);

        if (scores.isEmpty()) {
            Texto.drawString("No scores yet", WIDTH / 2f - 70, 350, 0.5f, 0.5f, 0.5f);
        } else {
            float y = 240;
            Texto.drawStringSmall("RANK  NAME          WAVE  TIME   SCORE   KILLS", 310, y - 30, 0.4f, 0.4f, 0.4f);
            for (int i = 0; i < Math.min(scores.size(), 10); i++) {
                ScoreManager.ScoreEntry e = scores.get(i);
                String line = String.format("#%-2d  %-12s  %4d  %5s  %6d  %5d",
                    i + 1, e.nome, e.wave, e.formatTempo(), e.score, e.kills);
                Texto.drawString(line, 310, y, 0.9f, 0.9f, 0.9f);
                y += 28;
            }
        }
        Texto.drawStringSmall("Click anywhere to return", WIDTH / 2f - 90, 640, 0.4f, 0.4f, 0.4f);
        if (Artes.isMouseLeftDown()) showHighScores = false;
    }
}
