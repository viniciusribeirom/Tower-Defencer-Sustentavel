package data.states;

import ajudas.Clock;
import ajudas.Texto;
import data.core.GameConfig;
import data.entities.Inimigo;
import data.entities.Projetil;
import data.enums.TipoDano;
import data.map.Tile;
import data.map.TileGrid;
import data.map.Pathfinder;
import data.player.Jogador;
import data.player.Player;
import data.save.GameSnapshot;
import data.save.SaveManager;
import data.towers.Torre;
import data.towers.TowerFactory;
import data.wave.Onda;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;

import static ajudas.Artes.*;
import static org.lwjgl.opengl.GL11.*;

/**
 * PlayState – Estado principal de gameplay.
 *
 * Responsabilidades:
 *  • Orquestrar grid, jogador, ondas, torres e input.
 *  • Renderização em camadas: grid → indicadores → inimigos → preview → torres → efeitos → HUD.
 *  • Auto-save entre ondas.
 *  • Transições para Pause (ESC/P) e GameOver.
 *
 * Correções aplicadas:
 *  • ChainEffects agora são gerenciados por esta classe (evita vazamento entre partidas).
 *  • Pathfinder.clearCache() chamado em initNewGame() para evitar rotas stale.
 *  • Fade-in suave ao entrar no estado.
 *
 * Design: Facade – coordena múltiplos subsistemas sem implementar suas lógicas internas.        
 * 
 */
public class PlayState extends State {
    private TileGrid grid;
    private Jogador jogador;
    private Onda onda;
    private Player player;
    private ArrayList<Torre> torres;
    private boolean autoSaved;
    private float fadeAlpha;
    private boolean fadingIn;
    private boolean escWasDown;
    private boolean pWasDown;

    // ChainEffects são gerenciados aqui (evita lista static em Projetil)
    private final ArrayList<Projetil.ChainEffect> chainEffects = new ArrayList<>();

    // Mapa padrão do jogo (15 linhas × 20 colunas)
    private static final int[][] DEFAULT_MAP = {
        {2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
        {2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
        {2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
        {2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,2,2},
        {2,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,2,2},
        {0,0,1,1,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0},
        {0,1,1,0,2,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0},
        {0,1,2,2,0,0,1,0,0,0,1,1,1,1,0,0,0,0,0,0},
        {0,1,1,1,0,1,1,0,0,0,1,0,0,1,0,0,0,0,0,0},
        {0,0,0,1,0,1,0,0,0,0,1,0,0,1,0,0,0,0,0,0},
        {0,2,0,1,0,1,1,1,2,0,1,0,0,1,0,0,0,0,0,0},
        {1,1,1,1,0,0,0,1,1,1,1,2,0,1,1,1,1,1,1,0},
        {2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2},
        {2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,2,2},
        {2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
    };

    public PlayState(StateManager sm, boolean loadSave) {
        super(sm);
        this.autoSaved = false;
        this.fadingIn = true;
        this.fadeAlpha = 1f;
        this.escWasDown = false;
        this.pWasDown = false;

        grid = new TileGrid(DEFAULT_MAP);
        torres = new ArrayList<>();

        if (loadSave) {
            GameSnapshot snap = SaveManager.load();
            if (snap != null) {
                restoreFromSnapshot(snap);
            } else {
                initNewGame();
            }
        } else {
            initNewGame();
        }
    }

    private void restoreFromSnapshot(GameSnapshot snap) {
        grid.importMap(snap.mapTiles);
        jogador = new Jogador(snap.vida, snap.dinheiro, snap.score, snap.inimigosMortos,
                              System.currentTimeMillis() - snap.tempoJogadoMs);
        for (data.save.TowerData td : snap.towers) {
            Tile t = grid.GetTile(td.tileX, td.tileY);
            if (t != null) {
                Torre tr = TowerFactory.create(TipoDano.values()[td.tipoDanoOrdinal], t);
                for (int i = 0; i < td.nivel; i++) tr.upgradeWithoutCost();
                torres.add(tr);
            }
        }
        player = new Player(grid);
        Inimigo ini = new Inimigo(QuickLoad("inimigo_verde"), grid.GetTile(0, 11), grid, 64, 64, data.enums.TipoInimigo.VERDE, 1);
        onda = new Onda(100, ini);
        onda.setWave(snap.wave);
    }

    private void initNewGame() {
        Pathfinder.clearCache();
        jogador = new Jogador(GameConfig.PLAYER_START_LIFE, GameConfig.PLAYER_START_MONEY);
        player = new Player(grid);
        Inimigo ini = new Inimigo(QuickLoad("inimigo_verde"), grid.GetTile(0, 11), grid, 64, 64, data.enums.TipoInimigo.VERDE, 1);
        onda = new Onda(100, ini);
        SaveManager.deleteSave();
    }

    @Override public void init() {}

    @Override
    public void enter() {
        if (Clock.isPaused()) Clock.Pause();
        Clock.reset();
        Clock.update();
    }

    @Override public void exit() {}

    @Override
    public void update() {
        if (fadingIn) {
            fadeAlpha -= 0.03f;
            if (fadeAlpha <= 0) fadingIn = false;
        }

        // Input: Pause
        boolean escNow = Keyboard.isKeyDown(Keyboard.KEY_ESCAPE);
        boolean pNow = Keyboard.isKeyDown(Keyboard.KEY_P);
        if ((escNow && !escWasDown) || (pNow && !pWasDown)) {
            sm.push(new PauseState(sm, this));
            escWasDown = escNow;
            pWasDown = pNow;
            return;
        }
        escWasDown = escNow;
        pWasDown = pNow;

        // Pular intervalo entre ondas
        if (onda.isEsperandoProxima() && Keyboard.isKeyDown(Keyboard.KEY_SPACE)) {
            onda.pularEspera();
        }

        // Atualiza subsistemas
        onda.update(jogador);
        player.update(torres, jogador);
        Torre nova = player.tentarConstruir(torres, jogador);
        if (nova != null) torres.add(nova);

        ArrayList<Inimigo> inimigos = onda.getInimigoList();
        for (Torre t : torres) t.update(inimigos, chainEffects);

        // Atualiza chain effects
        for (int i = chainEffects.size() - 1; i >= 0; i--) {
            if (!chainEffects.get(i).update()) chainEffects.remove(i);
        }

        // Auto-save entre ondas
        if (onda.isEsperandoProxima()) {
            if (!autoSaved) {
                autoSave();
                autoSaved = true;
            }
        } else {
            autoSaved = false;
        }

        // Game Over
        if (jogador.isGameOver()) {
            sm.set(new GameOverState(sm, jogador, onda.getNumeroOnda()));
        }
    }

    private void autoSave() {
        GameSnapshot gs = SaveManager.createFromGame(grid, jogador, torres, onda.getNumeroOnda());
        SaveManager.save(gs);
    }

    @Override
    public void render() {
        grid.Draw();
        drawSpawnIndicator();
        drawBaseIndicator();
        onda.draw();
        player.drawPreview(torres, onda.getInimigoList());
        for (Torre t : torres) t.draw();
        for (Projetil.ChainEffect c : chainEffects) c.draw();
        onda.drawFlashVermelho();
        drawHUD();
        if (fadeAlpha > 0) {
            DrawQuadColor(0, 0, GameConfig.GAME_WIDTH, GameConfig.GAME_HEIGHT, 0f, 0f, 1f, fadeAlpha);
        }
    }

    private void drawSpawnIndicator() {
        Tile spawn = grid.GetTile(0, 11);
        if (spawn == null) return;
        float x = spawn.getCenterX();
        float y = spawn.getY() + 10;
        long ms = System.currentTimeMillis();
        float bounce = (float) Math.sin(ms / 200.0) * 5f;
        float alpha = 0.5f + (float) Math.sin(ms / 300.0) * 0.3f;
        glDisable(GL_TEXTURE_2D);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glColor4f(1f, 0.9f, 0.2f, alpha);
        glBegin(GL_TRIANGLES);
        glVertex2f(x, y + bounce);
        glVertex2f(x - 10, y - 15 + bounce);
        glVertex2f(x + 10, y - 15 + bounce);
        glEnd();
        glColor4f(1f, 1f, 1f, 1f);
        glEnable(GL_TEXTURE_2D);
    }

    private void drawBaseIndicator() {
        Tile base = grid.GetTile(18, 11);
        if (base == null) return;
        float x = base.getCenterX();
        float y = base.getCenterY();
        long ms = System.currentTimeMillis();
        float pulse = 0.7f + (float) Math.sin(ms / 400.0) * 0.3f;
        DrawCircleFilled(x, y, 28 * pulse, 1f, 0.8f, 0.1f, 0.15f, 16);
        DrawCircle(x, y, 28 * pulse, 1f, 0.8f, 0.1f, 0.4f, 16);
        glDisable(GL_TEXTURE_2D);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glColor4f(1f, 0.2f, 0.2f, 0.8f);
        float s = 8;
        glPushMatrix();
        glTranslatef(x, y, 0);
        glRotatef((ms / 20f) % 360, 0, 0, 1);
        glBegin(GL_QUADS);
        glVertex2f(-s, -s); glVertex2f(s, -s); glVertex2f(s, s); glVertex2f(-s, s);
        glEnd();
        glPopMatrix();
        glColor4f(1f, 1f, 1f, 1f);
        glEnable(GL_TEXTURE_2D);
    }

    private void drawHUD() {
        float hudY = GameConfig.GAME_HEIGHT - 60;
        DrawQuadColor(0, hudY, GameConfig.GAME_WIDTH, 60, 0.03f, 0.03f, 0.05f, 0.95f);
        DrawQuadColor(0, hudY, GameConfig.GAME_WIDTH, 2, 0.2f, 0.6f, 0.3f, 0.9f);

        // Vida
        Texto.drawStringSmall("VIDA", 15, hudY + 8, 0.8f, 0.3f, 0.3f);
        data.ui.UIManager.drawProgressBar(15, hudY + 26, 160, 18, jogador.getVida() / (float) GameConfig.PLAYER_START_LIFE,
                                          0.9f, 0.15f, 0.15f, 0.15f, 0.05f, 0.05f);
        Texto.drawStringSmall(jogador.getVida() + "/" + GameConfig.PLAYER_START_LIFE, 180, hudY + 28, 1f, 1f, 1f);

        // Dinheiro
        Texto.drawString("$" + jogador.getDinheiro(), 250, hudY + 18, 1f, 0.85f, 0.1f);

        // Score
        Texto.drawStringSmall("SCORE", 380, hudY + 8, 0.5f, 0.5f, 0.5f);
        Texto.drawString(String.valueOf(jogador.getScore()), 380, hudY + 26, 0.9f, 0.9f, 0.9f);

        // Kills
        Texto.drawStringSmall("KILLS", 480, hudY + 8, 0.5f, 0.5f, 0.5f);
        Texto.drawString(String.valueOf(jogador.getInimigosMortos()), 480, hudY + 26, 0.9f, 0.9f, 0.9f);

        // Wave
        int ondaAtual = onda.getNumeroOnda();
        int total = onda.getInimigosMaximos();
        int rest = onda.getInimigosRestantes();
        int elim = total - rest;
        Texto.drawString("WAVE " + ondaAtual, 600, hudY + 6, 1f, 1f, 1f);
        data.ui.UIManager.drawProgressBar(600, hudY + 32, 140, 14,
            total > 0 ? (float) elim / total : 0, 0.15f, 0.75f, 0.25f, 0.1f, 0.1f, 0.1f);
        Texto.drawStringSmall(elim + "/" + total, 750, hudY + 32, 0.6f, 0.6f, 0.6f);

        // Tipo selecionado
        String tipoStr = "NORMAL";
        float tr = 1f, tg = 1f, tb = 1f;
        data.enums.TipoDano sel = player.getTipoTorreSelecionada();
        if (sel == data.enums.TipoDano.FOGO) { tipoStr = "FOGO"; tr = 1f; tg = 0.3f; tb = 0.1f; }
        else if (sel == data.enums.TipoDano.GELO) { tipoStr = "GELO"; tr = 0.2f; tg = 0.6f; tb = 1f; }
        else if (sel == data.enums.TipoDano.ELETRICO) { tipoStr = "ELET"; tr = 0.9f; tg = 0.8f; tb = 0.1f; }
        Texto.drawString(tipoStr, 860, hudY + 18, tr, tg, tb);

        // Build mode / hints
        if (player.isModoBuild()) {
            data.ui.UIManager.drawPanel(GameConfig.GAME_WIDTH - 290, hudY + 5, 280, 50, 0.8f);
            Texto.drawStringSmall("BUILD MODE  |  1:Fogo 2:Gelo 3:Elet C:Normal", GameConfig.GAME_WIDTH - 280, hudY + 20, 0.2f, 1f, 0.2f);
        } else {
        	Texto.drawStringSmall("ESC:Pause | U:Upgrade | RMB:Sell", GameConfig.GAME_WIDTH - 260, hudY + 24, 0.4f, 0.4f, 0.4f);
        }

        // Intervalo entre ondas
        if (onda.isEsperandoProxima()) {
            float tempo = onda.getTempoEntreOndas();
            int prox = ondaAtual + 1;
            float pw = 400, ph = 130, px = GameConfig.GAME_WIDTH / 2f - pw / 2f, py = GameConfig.GAME_HEIGHT / 2f - ph / 2f - 100;
            data.ui.UIManager.drawPanel(px, py, pw, ph, 0.92f);
            Texto.drawString("INTERVALO", GameConfig.GAME_WIDTH / 2f - 60, py + 12, 0.9f, 0.9f, 0.9f);
            Texto.drawString("Wave " + prox + " em " + (int) Math.ceil(tempo) + "s  [SPACE]", GameConfig.GAME_WIDTH / 2f - 130, py + 45, 1f, 1f, 1f);
            if (onda.isBossNaProxima()) {
                long ms = System.currentTimeMillis();
                float flash = (ms % 500) < 250 ? 1f : 0.3f;
                Texto.drawString(">>> BOSS INCOMING <<<", GameConfig.GAME_WIDTH / 2f - 150, py + 80, 1f, flash * 0.8f, flash * 0.1f);
            }
        }
    }

    // ---- Getters para PauseState ----
    public Jogador getJogador() { return jogador; }
    public TileGrid getGrid() { return grid; }
    public ArrayList<Torre> getTorres() { return torres; }
    public Onda getOnda() { return onda; }
    public Player getPlayer() { return player; }
}
