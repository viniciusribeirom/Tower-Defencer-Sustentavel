package data.states;

import ajudas.Clock;
import ajudas.Texto;
import data.save.GameSnapshot;
import data.save.SaveManager;
import data.ui.Button;
import data.ui.UIManager;
import static ajudas.Artes.*;

/**
 * PauseState – Overlay de pausa sobre o PlayState.
 *
 * Responsabilidades:
 *  • Pausar o relógio de jogo (Clock.Pause()).
 *  • Exibir overlay escurecido com opções: Resume, Save Game, Main Menu.
 *  • Salvar progresso atual em arquivo.
 *
 * Design: Estado de overlay (push/pop). Renderiza o PlayState por baixo
 * antes de desenhar o overlay, mantendo a ilusão de "congelamento".
 */
public class PauseState extends State {
    private final PlayState play;
    private Button btnResume, btnSave, btnMenu;
    private float overlayAlpha;

    public PauseState(StateManager sm, PlayState play) {
        super(sm);
        this.play = play;
    }

    @Override
    public void init() {
        Clock.Pause();
        overlayAlpha = 0;
        float bw = 260, bh = 45, bx = WIDTH / 2f - bw / 2f;

        btnResume = new Button(bx, 300, bw, bh, "Resume", () -> {
            Clock.Pause(); // toggle off
            sm.pop();
        });
        btnSave = new Button(bx, 370, bw, bh, "Save Game", () -> {
            GameSnapshot gs = SaveManager.createFromGame(play.getGrid(), play.getJogador(),
                                                          play.getTorres(), play.getOnda().getNumeroOnda());
            SaveManager.save(gs);
        });
        btnMenu = new Button(bx, 440, bw, bh, "Main Menu", () -> {
            if (Clock.isPaused()) Clock.Pause();
            sm.set(new MenuState(sm));
        });
    }

    @Override public void enter() {}
    @Override public void exit() {}

    @Override
    public void update() {
        if (overlayAlpha < 0.6f) overlayAlpha += 0.05f;
        btnResume.update();
        btnSave.update();
        btnMenu.update();
    }

    @Override
    public void render() {
        play.render();
        DrawQuadColor(0, 0, WIDTH, HEIGHT, 0f, 0f, 0f, overlayAlpha);
        UIManager.drawPanel(GAME_WIDTH / 2f - 180, 200, 360, 320, 0.95f);
        Texto.drawStringBig("PAUSED", GAME_WIDTH / 2f - 90, 230, 1f, 1f, 1f);
        btnResume.render();
        btnSave.render();
        btnMenu.render();
        if (btnSave.isHovered()) {
            Texto.drawStringSmall("Save current progress", btnSave.x + btnSave.width + 10, btnSave.y + 15, 0.3f, 0.8f, 0.3f);
        }
    }
}
