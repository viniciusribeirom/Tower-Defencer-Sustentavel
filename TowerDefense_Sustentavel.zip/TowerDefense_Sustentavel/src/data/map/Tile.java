package data.map;

import org.newdawn.slick.opengl.Texture;
import static ajudas.Artes.QuickLoad;

/**
 * Tile – Unidade básica do grid do mapa.
 *
 * Responsabilidades:
 *  • Armazenar posição mundial (x, y) e posição de grid (xPlace, yPlace).
 *  • Manter tipo (grama, terra, árvore) e textura associada.
 *  • Flag de ocupação por torre (evita sobreposição).
 *
 * Design: POJO com lazy-loading de textura via tileType. Coordenadas de grid
 * são calculadas automaticamente a partir da posição mundial.
 */
public class Tile {
    private float x, y;
    private float width, height;
    private Texture textura;
    private tileType type;
    private boolean temTorre = false;

    public Tile(float x, float y, float width, float height, tileType type) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.type = type;
        this.textura = QuickLoad(type.textureName);
    }

    // ---- Coordenadas mundiais ----
    public float getX() { return x; }
    public void setX(float x) { this.x = x; }
    public float getY() { return y; }
    public void setY(float y) { this.y = y; }

    // ---- Coordenadas de grid (derivadas) ----
    public int getXPlace() { return (int) (x / width); }
    public int getYPlace() { return (int) (y / height); }

    // ---- Dimensões ----
    public float getWidth()  { return width; }
    public void  setWidth(float w)  { this.width = w; }
    public float getHeight() { return height; }
    public void  setHeight(float h) { this.height = h; }

    // ---- Tipo & Textura ----
    public tileType getType() { return type; }
    public void setType(tileType type) {
        this.type = type;
        this.textura = QuickLoad(type.textureName);
    }
    public Texture getTextura() { return textura; }
    public void setTextura(Texture t) { this.textura = t; }

    // ---- Ocupação por torre ----
    public boolean hasTorre()      { return temTorre; }
    public void setTorre(boolean b) { this.temTorre = b; }

    /** Retorna o centro do tile em coordenadas mundiais. */
    public float getCenterX() { return x + width * 0.5f; }
    public float getCenterY() { return y + height * 0.5f; }
}
