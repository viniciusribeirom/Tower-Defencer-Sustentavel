package data.map;

import static ajudas.Artes.*;

import data.core.GameConfig;

/**
 * TileGrid – Grade bidimensional que compõe o mapa de jogo.
 *
 * Responsabilidades:
 *  • Armazenar matriz 20×15 de Tiles.
 *  • Construção a partir de matriz de inteiros (level design).
 *  • Serialização (export/import) para savegames.
 *  • Renderização batch do grid completo.
 *
 * Correções aplicadas:
 *  • exportMap() agora retorna int[GRID_WIDTH][GRID_HEIGHT] consistente com importMap().
 *  • Construtor int[][] interpreta newMap[y][x] (linha, coluna) para facilitar
 *    declaração literal no código (matriz visual).
 *
 * Design: Container de Tiles. Não contém lógica de gameplay.
 */
public class TileGrid {
    private Tile[][] map;

    /** Constrói grid totalmente de grama (mapa em branco). */
    public TileGrid() {
        map = new Tile[GameConfig.GRID_WIDTH][GameConfig.GRID_HEIGHT];
        for (int i = 0; i < GameConfig.GRID_WIDTH; i++) {
            for (int j = 0; j < GameConfig.GRID_HEIGHT; j++) {
                map[i][j] = new Tile(i * GameConfig.TILE_SIZE, j * GameConfig.TILE_SIZE,
                                     GameConfig.TILE_SIZE, GameConfig.TILE_SIZE, tileType.Grama);
            }
        }
    }

    /**
     * Constrói grid a partir de matriz literal.
     * @param newMap matriz[linha][coluna] onde cada valor é o ordinal do tileType.
     */
    public TileGrid(int[][] newMap) {
        map = new Tile[GameConfig.GRID_WIDTH][GameConfig.GRID_HEIGHT];
        for (int i = 0; i < GameConfig.GRID_WIDTH; i++) {
            for (int j = 0; j < GameConfig.GRID_HEIGHT; j++) {
                tileType tipo = tileType.values()[newMap[j][i]]; // newMap[y][x]
                map[i][j] = new Tile(i * GameConfig.TILE_SIZE, j * GameConfig.TILE_SIZE,
                                     GameConfig.TILE_SIZE, GameConfig.TILE_SIZE, tipo);
            }
        }
    }

    public void SetTile(int xCoord, int yCoord, tileType type) {
        if (!isValid(xCoord, yCoord)) return;
        map[xCoord][yCoord] = new Tile(xCoord * GameConfig.TILE_SIZE, yCoord * GameConfig.TILE_SIZE,
                                         GameConfig.TILE_SIZE, GameConfig.TILE_SIZE, type);
    }

    public Tile GetTile(int xPlace, int yPlace) {
        if (!isValid(xPlace, yPlace)) return null;
        return map[xPlace][yPlace];
    }

    private boolean isValid(int x, int y) {
        return x >= 0 && x < GameConfig.GRID_WIDTH && y >= 0 && y < GameConfig.GRID_HEIGHT;
    }

    /** Renderiza todos os tiles (fundo do mapa). */
    public void Draw() {
        for (int i = 0; i < GameConfig.GRID_WIDTH; i++) {
            for (int j = 0; j < GameConfig.GRID_HEIGHT; j++) {
                Tile t = map[i][j];
                if (t != null) DrawQuardTex(t.getTextura(), t.getX(), t.getY(), t.getWidth(), t.getHeight());
            }
        }
    }

    /** Exporta o estado atual do grid para int[GRID_WIDTH][GRID_HEIGHT]. */
    public int[][] exportMap() {
        int[][] result = new int[GameConfig.GRID_WIDTH][GameConfig.GRID_HEIGHT];
        for (int i = 0; i < GameConfig.GRID_WIDTH; i++) {
            for (int j = 0; j < GameConfig.GRID_HEIGHT; j++) {
                result[i][j] = map[i][j].getType().ordinal();
            }
        }
        return result;
    }

    /** Restaura grid a partir de dados serializados. */
    public void importMap(int[][] data) {
        if (data == null || data.length != GameConfig.GRID_WIDTH) return;
        for (int i = 0; i < GameConfig.GRID_WIDTH; i++) {
            for (int j = 0; j < GameConfig.GRID_HEIGHT; j++) {
                int idx = data[i][j];
                if (idx >= 0 && idx < tileType.values().length) {
                    SetTile(i, j, tileType.values()[idx]);
                }
            }
        }
    }
}
