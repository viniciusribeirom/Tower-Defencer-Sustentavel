package data.map;

/**
 * tileType – Enum dos tipos de terreno do grid.
 *
 * Responsabilidades:
 *  • Associar nome de textura (asset) a cada tipo.
 *  • Definir se o tile permite construção de torres (buildable).
 *
 * Design: Enum extensível. Adicionar novos biomas é trivial.
 */
public enum tileType {
    Grama("grama", true),
    Terra("terra", false),
    Arvore("arvore", false);

    public final String textureName;
    public final boolean buildable;

    tileType(String textureName, boolean buildable) {
        this.textureName = textureName;
        this.buildable = buildable;
    }
}
