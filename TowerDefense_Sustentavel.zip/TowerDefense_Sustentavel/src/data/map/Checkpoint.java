package data.map;

/**
 * Checkpoint – Ponto de referência no pathfinding dos inimigos.
 *
 * Cada checkpoint armazena um tile alvo e a direção (vetor unitário em grid)
 * que o inimigo deve seguir para chegar até ele.
 *
 * Design: POJO imutável (exceto se necessário). Usado exclusivamente pelo
 * Pathfinder para construir a rota completa do mapa.
 */
public class Checkpoint {
    private final Tile tile;
    private final int xDirection;
    private final int yDirection;

    public Checkpoint(Tile tile, int xDirection, int yDirection) {
        this.tile = tile;
        this.xDirection = xDirection;
        this.yDirection = yDirection;
    }

    public Tile getTile()          { return tile; }
    public int  getxDirection()    { return xDirection; }
    public int  getyDirection()    { return yDirection; }
}
