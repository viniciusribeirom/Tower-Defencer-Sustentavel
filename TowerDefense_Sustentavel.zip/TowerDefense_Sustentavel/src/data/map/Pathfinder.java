package data.map;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Pathfinder – Sistema de geração e cache de rotas para inimigos.
 *
 * Responsabilidades:
 *  • Calcular a sequência de Checkpoints a partir de um tile inicial.
 *  • Cachear rotas por chave composta (grid + startTile) para evitar
 *    recalcular a cada spawn (otimização de CPU).
 *  • Validação de limites e detecção de fim de caminho.
 *
 * Algoritmo: Greedy walk – assume que o mapa possui um único caminho contínuo
 * de tiles do mesmo tipo (Terra). Não suporta loops (proposital para TD clássico).
 *
 * Design: Utilitário estático. Thread-safe para uso single-threaded do game loop.
 */
public final class Pathfinder {
    private static final Map<String, ArrayList<Checkpoint>> cache = new HashMap<>();

    private Pathfinder() {}

    /** Gera ou recupera do cache a rota completa. */
    public static ArrayList<Checkpoint> findPath(TileGrid grid, Tile startTile) {
        String key = grid.hashCode() + "_" + startTile.getXPlace() + "_" + startTile.getYPlace();
        ArrayList<Checkpoint> cached = cache.get(key);
        if (cached != null) {
            return cloneCheckpoints(cached);
        }
        ArrayList<Checkpoint> path = buildPath(grid, startTile);
        cache.put(key, cloneCheckpoints(path));
        return path;
    }

    /** Limpa todo o cache (útil ao reiniciar partida ou modificar mapa). */
    public static void clearCache() {
        cache.clear();
    }

    private static ArrayList<Checkpoint> buildPath(TileGrid grid, Tile startTile) {
        ArrayList<Checkpoint> checkpoints = new ArrayList<>();
        int[] directions = findNextDirection(grid, startTile, new int[]{0, 0});
        if (directions[0] == 2) return checkpoints; // sem saída

        checkpoints.add(findNextCheckpoint(grid, startTile, directions));
        int counter = 0;
        while (counter < checkpoints.size() && counter < 50) {
            int[] currentDir = findNextDirection(grid, checkpoints.get(counter).getTile(), directions);
            if (currentDir[0] == 2 || counter >= 49) break;
            directions = currentDir;
            Checkpoint next = findNextCheckpoint(grid, checkpoints.get(counter).getTile(), directions);
            if (isDuplicate(next, checkpoints)) break;
            checkpoints.add(next);
            counter++;
        }
        return checkpoints;
    }

    private static boolean isDuplicate(Checkpoint cp, ArrayList<Checkpoint> list) {
        for (Checkpoint c : list) {
            if (c.getTile().getXPlace() == cp.getTile().getXPlace() &&
                c.getTile().getYPlace() == cp.getTile().getYPlace()) {
                return true;
            }
        }
        return false;
    }

    private static Checkpoint findNextCheckpoint(TileGrid grid, Tile s, int[] dir) {
        Tile next = null;
        boolean found = false;
        int counter = 1;
        int maxGridW = data.core.GameConfig.GRID_WIDTH;
        int maxGridH = data.core.GameConfig.GRID_HEIGHT;

        while (!found) {
            int nextX = s.getXPlace() + dir[0] * counter;
            int nextY = s.getYPlace() + dir[1] * counter;
            if (nextX < 0 || nextX >= maxGridW || nextY < 0 || nextY >= maxGridH) {
                found = true;
                counter -= 1;
                next = grid.GetTile(s.getXPlace() + dir[0] * counter, s.getYPlace() + dir[1] * counter);
                break;
            }
            if (s.getType() != grid.GetTile(nextX, nextY).getType()) {
                found = true;
                counter -= 1;
                next = grid.GetTile(s.getXPlace() + dir[0] * counter, s.getYPlace() + dir[1] * counter);
            }
            counter++;
        }
        return new Checkpoint(next, dir[0], dir[1]);
    }

    private static int[] findNextDirection(TileGrid grid, Tile s, int[] previousDir) {
        int[] dir = new int[2];
        int x = s.getXPlace();
        int y = s.getYPlace();
        int maxW = data.core.GameConfig.GRID_WIDTH;
        int maxH = data.core.GameConfig.GRID_HEIGHT;

        Tile u = (y > 0)      ? grid.GetTile(x, y - 1) : null;
        Tile r = (x < maxW-1) ? grid.GetTile(x + 1, y) : null;
        Tile d = (y < maxH-1) ? grid.GetTile(x, y + 1) : null;
        Tile l = (x > 0)      ? grid.GetTile(x - 1, y) : null;

        // Prioridade: cima, direita, baixo, esquerda (evita voltar por onde veio)
        if (u != null && s.getType() == u.getType() && previousDir[1] != 1) {
            dir[0] = 0; dir[1] = -1;
        } else if (r != null && s.getType() == r.getType() && previousDir[0] != -1) {
            dir[0] = 1; dir[1] = 0;
        } else if (d != null && s.getType() == d.getType() && previousDir[1] != -1) {
            dir[0] = 0; dir[1] = 1;
        } else if (l != null && s.getType() == l.getType() && previousDir[0] != 1) {
            dir[0] = -1; dir[1] = 0;
        } else {
            dir[0] = 2; dir[1] = 2; // sem saída
        }
        return dir;
    }

    private static ArrayList<Checkpoint> cloneCheckpoints(ArrayList<Checkpoint> original) {
        ArrayList<Checkpoint> clone = new ArrayList<>();
        for (Checkpoint cp : original) {
            clone.add(new Checkpoint(cp.getTile(), cp.getxDirection(), cp.getyDirection()));
        }
        return clone;
    }
}
