package data.wave;

import data.core.GameConfig;
import data.entities.Inimigo;
import data.entities.Particula;
import data.enums.TipoInimigo;
import data.map.Tile;
import data.map.TileGrid;
import data.player.Jogador;
import ajudas.AudioManager;
import org.newdawn.slick.opengl.Texture;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import static ajudas.Artes.*;
import static ajudas.Clock.Delta;

/**
 * Onda – Gerenciador de spawn e ciclo de vida dos inimigos.
 *
 * Responsabilidades:
 *  • Composição procedural de cada wave (verde, vermelho, azul, boss).
 *  • Spawn temporizado de inimigos com base no delta time.
 *  • Intervalo entre ondas com contagem regressiva (skippable via SPACE).
 *  • Aplicação de dano à base, recompensas, partículas de morte e flash vermelho.
 *  • Detecção de fim de onda → inicia próxima com dificuldade escalonada.
 *
 * Correções aplicadas:
 *  • timeSinceLastSpawn inicializado como 0 (não como spawnTime) para evitar
 *    delay artificial no primeiro spawn.
 *  • Spawn de boss a cada 5 ondas com composição ajustada.
 *  • Flash vermelho decresce com Delta() corretamente.
 *
 * Design: Container de Inimigos. Não renderiza (PlayState chama draw()).
 */
public class Onda {
    private float timeSinceLastSpawn;
    private float spawnTime;
    private final Inimigo inimigoBase; // template para posição inicial e grid

    private final ArrayList<Inimigo> inimigoList;
    private int numeroOnda;
    private int inimigosMaximos;
    private boolean ondaAtiva;
    private float tempoEntreOndas;
    private boolean esperandoProxima;
    private boolean bossNaProxima;
    private final ArrayList<TipoInimigo> filaSpawn;

    private final ArrayList<Particula> particulas;
    private float flashVermelho;

    public Onda(float spawnTime, Inimigo inimigoBase) {
        this.inimigoBase = inimigoBase;
        this.spawnTime = spawnTime;
        this.inimigoList = new ArrayList<>();
        this.filaSpawn = new ArrayList<>();
        this.timeSinceLastSpawn = 0;
        this.numeroOnda = 1;
        this.ondaAtiva = false;
        this.tempoEntreOndas = GameConfig.WAVE_INTERVAL_BASE;
        this.esperandoProxima = true;
        this.bossNaProxima = false;
        this.particulas = new ArrayList<>();
        this.flashVermelho = 0f;
        gerarComposicaoOnda();
    }

    public void update(Jogador jogador) {
        if (esperandoProxima) {
            tempoEntreOndas -= Delta();
            if (tempoEntreOndas <= 0) iniciarOnda();
            updateParticulas();
            if (flashVermelho > 0) flashVermelho -= Delta();
            return;
        }

        if (!ondaAtiva) return;

        timeSinceLastSpawn += Delta();
        if (timeSinceLastSpawn > spawnTime && !filaSpawn.isEmpty()) {
            spawnNext();
            timeSinceLastSpawn = 0;
        }

        if (filaSpawn.isEmpty() && inimigoList.isEmpty()) {
            finalizarOnda();
        }

        // Atualiza inimigos vivos
        for (Inimigo ini : inimigoList) {
            if (ini.isAlive()) ini.update();
        }

        // Processa mortes e chegadas
        Iterator<Inimigo> it = inimigoList.iterator();
        while (it.hasNext()) {
            Inimigo i = it.next();
            if (!i.isAlive()) {
                if (i.chegouAoFinal()) {
                    int danoBase = (i.getTipo() == TipoInimigo.BOSS) ? 5 : 1;
                    jogador.perderVida(danoBase);
                    flashVermelho = 0.3f;
                    AudioManager.play("dano_base", 1.0f, 0.9f);
                } else {
                    // Morte: partículas e recompensas
                    for (int p = 0; p < 10; p++) {
                        particulas.add(Particula.morte(i.getCenterX(), i.getCenterY()));
                    }
                    AudioManager.play("morte", 0.8f + (float) Math.random() * 0.4f, 0.5f);
                    jogador.ganharDinheiro(i.getRecompensa());
                    jogador.adicionarScore(i.getRecompensa() * 10);
                    jogador.registrarKill();
                }
                it.remove();
            }
        }

        updateParticulas();
        if (flashVermelho > 0) flashVermelho -= Delta();
    }

    private void updateParticulas() {
        Iterator<Particula> it = particulas.iterator();
        while (it.hasNext()) {
            if (!it.next().isAlive()) it.remove();
        }
    }

    private void spawnNext() {
        if (filaSpawn.isEmpty()) return;
        TipoInimigo tipo = filaSpawn.remove(0);
        Texture tex = QuickLoad(tipo.textureName);
        inimigoList.add(new Inimigo(
            tex,
            inimigoBase.getStartTile(),
            inimigoBase.getTileGrid(),
            64, 64,
            tipo,
            numeroOnda
        ));
    }

    private void gerarComposicaoOnda() {
        filaSpawn.clear();
        int total = 5 + (numeroOnda - 1) * 3;
        int verdes = total;
        int vermelhos = 0;
        int azuis = 0;
        boolean temBoss = (numeroOnda % 5 == 0);
        bossNaProxima = temBoss;

        if (numeroOnda >= 3) {
            vermelhos = Math.min((numeroOnda - 2) * 2, total / 3);
            verdes -= vermelhos;
        }
        if (numeroOnda >= 5) {
            azuis = Math.min((numeroOnda - 4), total / 4);
            verdes -= azuis;
        }
        if (temBoss) {
            verdes = Math.max(verdes - 1, 2);
        }
        if (verdes < 0) verdes = 0;

        for (int i = 0; i < verdes; i++)    filaSpawn.add(TipoInimigo.VERDE);
        for (int i = 0; i < vermelhos; i++) filaSpawn.add(TipoInimigo.VERMELHO);
        for (int i = 0; i < azuis; i++)     filaSpawn.add(TipoInimigo.AZUL);
        if (temBoss) filaSpawn.add(TipoInimigo.BOSS);

        Collections.shuffle(filaSpawn);
        inimigosMaximos = filaSpawn.size();
    }

    private void iniciarOnda() {
        esperandoProxima = false;
        ondaAtiva = true;
        timeSinceLastSpawn = 0; // não começa com delay
        AudioManager.play("wave_start", 1.0f, 0.7f);
    }

    private void finalizarOnda() {
        ondaAtiva = false;
        esperandoProxima = true;
        tempoEntreOndas = GameConfig.WAVE_INTERVAL_BASE;
        numeroOnda++;
        spawnTime = Math.max(30f, 100f - numeroOnda * 5f);
        gerarComposicaoOnda();
    }

    public void pularEspera() {
        tempoEntreOndas = 0;
    }

    public void setWave(int wave) {
        numeroOnda = wave - 1;
        finalizarOnda();
    }

    public void draw() {
        for (Inimigo ini : inimigoList) {
            if (ini.isAlive()) ini.draw();
        }
        for (Particula p : particulas) p.draw();
    }

    public void drawFlashVermelho() {
        if (flashVermelho > 0) {
            DrawQuadColor(0, 0, GameConfig.GAME_WIDTH, GameConfig.GAME_HEIGHT, 1f, 0f, 0f, flashVermelho * 0.4f);
        }
    }

    // ---- Getters ----
    public ArrayList<Inimigo> getInimigoList() { return inimigoList; }
    public int getNumeroOnda() { return numeroOnda; }
    public int getInimigosMaximos() { return inimigosMaximos; }
    public int getInimigosRestantes() {
        return inimigoList.size() + filaSpawn.size();
    }
    public boolean isEsperandoProxima() { return esperandoProxima; }
    public float getTempoEntreOndas() { return tempoEntreOndas; }
    public boolean isBossNaProxima() { return bossNaProxima; }
}
