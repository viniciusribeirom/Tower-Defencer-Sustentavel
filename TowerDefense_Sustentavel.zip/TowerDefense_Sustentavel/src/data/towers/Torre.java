package data.towers;

import data.core.Entity;
import data.core.GameConfig;
import data.entities.Inimigo;
import data.entities.Projetil;
import data.enums.TipoDano;
import data.map.Tile;
import data.player.Jogador;
import ajudas.Texto;
import ajudas.AudioManager;
import org.newdawn.slick.opengl.Texture;

import java.util.ArrayList;
import java.util.Iterator;

import static ajudas.Artes.*;
import static ajudas.Clock.Delta;
import static org.lwjgl.opengl.GL11.*;

/**
 * Torre – Classe abstrata base para todas as torres defensivas.
 *
 * Pilares da POO aplicados:
 *  • ABSTRAÇÃO: define contrato de update(), draw(), atirar(), encontrarAlvo().
 *  • HERANÇA: TorreCanhao (e futuras) estendem esta classe.
 *  • POLIMORFISMO: coleções de Torre podem ser tratadas uniformemente pelo PlayState.
 *  • ENCAPSULAMENTO: atributos de balanceamento (damage, alcance, cooldown) protegidos.
 *
 * Responsabilidades:
 *  • Gerenciamento de cooldown e disparo automático.
 *  • Sistema de upgrade em 3 níveis com escalonamento configurável.
 *  • Renderização de projéteis, barra de cooldown e indicador de nível.
 *  • Preview de alcance e linha tracejada para alvo atual.
 */
public abstract class Torre extends Entity {
    protected int custo;
    protected int custoTotalInvestido;
    protected int damage;
    protected int damageBase;
    protected float alcance;
    protected float alcanceBase;
    protected float cooldown;
    protected float cooldownBase;
    protected float timerCooldown;
    protected Texture textureBala;
    protected Tile startTile;
    protected ArrayList<Projetil> projeteis;
    protected boolean podeAtirar;
    protected TipoDano tipoDano;
    protected int nivel;

    public Torre(Texture texture, Tile startTile, int damage, float alcance,
                 float cooldown, int custo, TipoDano tipoDano) {
        super(startTile.getX(), startTile.getY(), startTile.getWidth(), startTile.getHeight(), texture);
        this.startTile = startTile;
        this.damageBase = damage;
        this.damage = damage;
        this.alcanceBase = alcance;
        this.alcance = alcance;
        this.cooldownBase = cooldown;
        this.cooldown = cooldown;
        this.custo = custo;
        this.custoTotalInvestido = custo;
        this.tipoDano = tipoDano;
        this.timerCooldown = 0;
        this.podeAtirar = false;
        this.projeteis = new ArrayList<>();
        this.textureBala = QuickLoad("bala");
        this.nivel = 0;
    }

    /**
     * Tenta realizar upgrade pagando com dinheiro do jogador.
     * @return true se o upgrade foi bem-sucedido.
     */
    public boolean upgrade(Jogador jogador) {
        if (nivel >= GameConfig.TOWER_MAX_LEVEL) return false;
        int custoUpgrade = getCustoUpgrade();
        if (!jogador.gastar(custoUpgrade)) {
            AudioManager.play("erro", 1.5f, 0.4f);
            return false;
        }
        aplicarUpgrade(custoUpgrade);
        AudioManager.play("upgrade", 1.0f, 0.8f);
        return true;
    }

    /** Aplica upgrade sem custo (usado em load de savegame). */
    public void upgradeWithoutCost() {
        if (nivel >= GameConfig.TOWER_MAX_LEVEL) return;
        aplicarUpgrade(0);
    }

    private void aplicarUpgrade(int custoPago) {
        nivel++;
        custoTotalInvestido += custoPago;
        damage = (int) (damageBase * (1f + nivel * GameConfig.TOWER_UPGRADE_DAMAGE_MULT));
        alcance = alcanceBase * (1f + nivel * GameConfig.TOWER_UPGRADE_RANGE_MULT);
        cooldown = Math.max(0.2f, cooldownBase * (1f - nivel * GameConfig.TOWER_UPGRADE_COOLDOWN_MULT));
    }

    public int getCustoUpgrade() {
        if (nivel >= GameConfig.TOWER_MAX_LEVEL) return 0;
        return (int) (GameConfig.TOWER_UPGRADE_COST_BASE + nivel * GameConfig.TOWER_UPGRADE_COST_STEP);
    }

    public int getCustoVenda() {
        return custoTotalInvestido / 2;
    }

    @Override
    public void update() {
        // Atualiza cooldown
        timerCooldown += Delta();
        if (timerCooldown >= cooldown) {
            timerCooldown = cooldown;
            podeAtirar = true;
        }
    }

    /**
     * Atualização com contexto de inimigos (para encontrar alvo e atualizar projéteis).
     * @param inimigos lista de inimigos vivos na onda.
     * @param chainList lista mutável para acumular ChainEffects (ELETRICO).
     */
    public void update(ArrayList<Inimigo> inimigos, ArrayList<Projetil.ChainEffect> chainList) {
        update(); // cooldown
        if (podeAtirar) {
            Inimigo alvo = encontrarAlvo(inimigos);
            if (alvo != null) {
                atirar(alvo);
                timerCooldown = -25;
                podeAtirar = false;
            }
        }
        Iterator<Projetil> it = projeteis.iterator();
        while (it.hasNext()) {
            Projetil p = it.next();
            p.update(inimigos, chainList);
            if (!p.isAlive()) it.remove();
        }
    }

    protected void atirar(Inimigo alvo) {
        float px = x + width * 0.5f - 8;
        float py = y + height * 0.5f - 8;
        TipoDano tipoParaProjetil = (this.tipoDano != null) ? this.tipoDano : TipoDano.NORMAL;
        projeteis.add(new Projetil(textureBala, px, py, 16, 16, 10f, damage, alvo, tipoParaProjetil));

        // SFX diferenciado por tipo
        if (tipoDano == TipoDano.FOGO)      AudioManager.play("tiro", 1.2f, 0.7f);
        else if (tipoDano == TipoDano.GELO) AudioManager.play("tiro", 0.9f, 0.6f);
        else if (tipoDano == TipoDano.ELETRICO) AudioManager.play("tiro", 1.5f, 0.5f);
        else AudioManager.play("tiro", 1.0f, 0.6f);
    }

    protected Inimigo encontrarAlvo(ArrayList<Inimigo> inimigos) {
        for (Inimigo i : inimigos) {
            if (!i.isAlive()) continue;
            float dx = i.getX() - x;
            float dy = i.getY() - y;
            float dist = (float) Math.sqrt(dx * dx + dy * dy);
            if (dist <= alcance) return i;
        }
        return null;
    }

    /** Desenha preview circular de alcance (usado no hover e build mode). */
    public void drawPreview(float mouseX, float mouseY, boolean valido, ArrayList<Inimigo> inimigos) {
        float cx = x + width * 0.5f;
        float cy = y + height * 0.5f;
        float[] cor = getCorPorTipo();
        DrawCircleFilled(cx, cy, alcance, cor[0], cor[1], cor[2], 0.12f, 32);
        DrawCircle(cx, cy, alcance, cor[0], cor[1], cor[2], 0.3f, 32);

        if (valido && inimigos != null) {
            Inimigo alvo = encontrarAlvo(inimigos);
            if (alvo != null) {
                drawLinhaTracejada(cx, cy, alvo.getCenterX(), alvo.getCenterY(), cor[0], cor[1], cor[2]);
            }
        }
    }

    private void drawLinhaTracejada(float x1, float y1, float x2, float y2, float r, float g, float b) {
        glDisable(GL_TEXTURE_2D);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glColor4f(r, g, b, 0.5f);
        float dist = (float) Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
        int segmentos = (int) (dist / 10f);
        glBegin(GL_LINES);
        for (int i = 0; i < segmentos; i += 2) {
            float t1 = (float) i / segmentos;
            float t2 = (float) (i + 1) / segmentos;
            glVertex2f(x1 + (x2 - x1) * t1, y1 + (y2 - y1) * t1);
            glVertex2f(x1 + (x2 - x1) * t2, y1 + (y2 - y1) * t2);
        }
        glEnd();
        glColor4f(1f, 1f, 1f, 1f);
        glEnable(GL_TEXTURE_2D);
    }

    protected float[] getCorPorTipo() {
        if (tipoDano == TipoDano.FOGO)      return new float[]{1f, 0.3f, 0.1f};
        if (tipoDano == TipoDano.GELO)       return new float[]{0.2f, 0.6f, 1f};
        if (tipoDano == TipoDano.ELETRICO)   return new float[]{0.9f, 0.8f, 0.1f};
        return new float[]{0.2f, 1f, 0.2f};
    }

    private void drawCooldown() {
        if (timerCooldown >= cooldown) return;
        float barW = 40;
        float barH = 4;
        float barX = x + (width - barW) * 0.5f;
        float barY = y + height + 4;
        float pct = Math.min(timerCooldown / cooldown, 1f);
        DrawQuadColor(barX, barY, barW, barH, 0.2f, 0.2f, 0.2f, 0.7f);
        if (pct > 0) DrawQuadColor(barX, barY, barW * pct, barH, 1f, 0.85f, 0f, 0.9f);
    }

    private void drawNivel() {
        if (nivel <= 0) return;
        String txt = "+" + nivel;
        float nx = x + width * 0.5f - 8;
        float ny = y - 18;
        DrawQuadColor(nx - 4, ny - 2, 24, 18, 0f, 0f, 0f, 0.6f);
        float r = 1f, g = 1f, b = 1f;
        if (nivel == 2) { r = 1f; g = 0.9f; b = 0.2f; }
        else if (nivel == 3) { r = 1f; g = 0.5f; b = 0.1f; }
        Texto.drawString(txt, nx, ny, r, g, b);
    }

    @Override
    public void draw() {
        DrawQuardTex(texture, x, y, width, height);
        for (Projetil p : projeteis) p.draw();
        drawCooldown();
        drawNivel();
    }

    // ---- Getters ----
    public TipoDano getTipoDano()      { return tipoDano; }
    public int      getCusto()         { return custo; }
    public int      getCustoTotalInvestido() { return custoTotalInvestido; }
    public int      getNivel()         { return nivel; }
    public Tile     getStartTile()     { return startTile; }
    public float    getAlcance()       { return alcance; }
    public int      getDamage()        { return damage; }
    public float    getCooldown()      { return cooldown; }
}
