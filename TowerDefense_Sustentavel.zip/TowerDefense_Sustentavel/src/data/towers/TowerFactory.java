package data.towers;

import data.core.GameConfig;
import data.enums.TipoDano;
import data.map.Tile;
import org.newdawn.slick.opengl.Texture;
import static ajudas.Artes.QuickLoad;

/**
 * TowerFactory – Padrão Factory para criação de torres.
 *
 * Responsabilidades:
 *  • Centralizar a lógica de criação de torres (qual imagem, qual custo, qual stats).
 *  • Evitar duplicação de código entre Player (build) e PlayState (load de save).
 *  • Facilitar adição de novos tipos de torre sem modificar múltiplas classes.
 *
 * Design: Classe utilitária estática. Cada método factory encapsula os parâmetros
 * de balanceamento de uma torre específica.
 */
public final class TowerFactory {
    private TowerFactory() {}

    public static Torre create(TipoDano tipo, Tile tile) {
        String imgName = getImageName(tipo);
        Texture tex = QuickLoad(imgName);
        int custo = (tipo == TipoDano.ELETRICO) ? GameConfig.TOWER_COST_ELETRICO : GameConfig.TOWER_COST_BASE;

        switch (tipo) {
            case FOGO:
                return new TorreCanhao(tex, tile, 15, 260f, 1.5f, custo, TipoDano.FOGO);
            case GELO:
                return new TorreCanhao(tex, tile, 8, 220f, 1.0f, custo, TipoDano.GELO);
            case ELETRICO:
                return new TorreCanhao(tex, tile, 12, 300f, 1.6f, custo, TipoDano.ELETRICO);
            case NORMAL:
            default:
                return new TorreCanhao(tex, tile, 10, 280f, 1.2f, custo, TipoDano.NORMAL);
        }
    }

    public static String getImageName(TipoDano tipo) {
        switch (tipo) {
            case FOGO:     return "torre_fogo";
            case GELO:     return "torre_gelo";
            case ELETRICO: return "torre_eletrico";
            default:       return "torre_base";
        }
    }

    public static float getAlcancePreview(TipoDano tipo) {
        switch (tipo) {
            case FOGO:     return 260f;
            case GELO:     return 220f;
            case ELETRICO: return 300f;
            default:       return 280f;
        }
    }
}
