package data.towers;

import data.enums.TipoDano;
import data.map.Tile;
import org.newdawn.slick.opengl.Texture;

/**
 * TorreCanhao – Implementação concreta de Torre.
 *
 * Atualmente funciona como fábrica de torres com diferentes parâmetros.
 * Futuramente pode ter comportamentos únicos (morteiros, lasers, etc.).
 *
 * Design: Herança simples. A lógica de disparo e upgrade está toda na classe base.
 */
public class TorreCanhao extends Torre {
    public TorreCanhao(Texture texture, Tile startTile, int damage, float alcance,
                       float cooldown, int custo, TipoDano tipoDano) {
        super(texture, startTile, damage, alcance, cooldown, custo, tipoDano);
    }
}
