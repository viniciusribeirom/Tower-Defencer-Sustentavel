package data;

import ajudas.AudioManager;
import ajudas.Clock;
import ajudas.Texto;
import data.states.MenuState;
import data.states.StateManager;
import org.lwjgl.opengl.Display;
import static org.lwjgl.opengl.GL11.*;
import static ajudas.Artes.BeginSession;

/**
 * Boot – Ponto de entrada da aplicação.
 *
 * Responsabilidades:
 *  • Inicializar subsistemas na ordem correta (GL → Audio → Fontes → Clock → States).
 *  • Executar game loop principal (update → render → sync 60 FPS).
 *  • Cleanup ordenado ao fechar janela.
 *
 * Design: Classe main simples. 
 */
public class Boot {

    public Boot() {
        System.out.println("========================================");
        System.out.println("  Tower Defense !!!!  ");
        System.out.println("  Iniciando subsistemas...            ");
        System.out.println("========================================");

        BeginSession();
        AudioManager.init();
        Texto.init();
        Clock.reset();
        StateManager.init();
        StateManager.getInstance().set(new MenuState(StateManager.getInstance()));

        // Game Loop principal
        while (!Display.isCloseRequested()) {
            Clock.update();
            glClear(GL_COLOR_BUFFER_BIT);
            StateManager.getInstance().update();
            StateManager.getInstance().render();
            Display.update();
            Display.sync(60);
        }

        // Cleanup
        AudioManager.cleanup();
        Display.destroy();
        System.out.println("[Boot] Encerrando");
    }

    public static void main(String[] args) {
        new Boot();
    }
}
