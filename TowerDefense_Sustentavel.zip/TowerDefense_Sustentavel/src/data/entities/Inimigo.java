package data.entities;

import data.core.Entity;
import data.core.GameConfig;
import data.effects.EfeitoStatus;
import data.enums.TipoDano;
import data.enums.TipoInimigo;
import data.map.Checkpoint;
import data.map.Pathfinder;
import data.map.Tile;
import data.map.TileGrid;
import org.newdawn.slick.opengl.Texture;

import java.util.ArrayList;
import java.util.Iterator;

import static ajudas.Artes.*;
import static ajudas.Clock.Delta;

/**
 * Inimigo – Entidade que percorre o caminho do mapa em direção à base.
 *
 * Herança: estende Entity (posição, textura, alive, draw base).
 * Polimorfismo: update() sobrescrito com conf de movimento e aplicação de efeitos.
 *
 * Responsabilidades:
 *  • Movimentação via checkpoints gerados pelo Pathfinder.
 *  • Recepção de dano (com acumulador fracionário para DOTs precisos).
 *  • Gerenciamento de efeitos de status (fogo, gelo).
 *  • Escalonamento de atributos conforme o nível da onda.
 *
 * Correções críticas aplicadas:
 *  • Pathfinding extraído para Pathfinder (SRP, cache global).
 *  • takeDamage(float) agora acumula dano residual em damageAccumulator,
 *    evitando que DOTs fracionários sejam truncados para zero.
 *  • Movimento usa distância ao quadrado para evitar sqrt desnecessário
 *    no teste de chegada ao checkpoint.
 */
public class Inimigo extends Entity {
    private int health;
    private int healthMax;
    private int currentCheckpoint;
    private float speed;
    private float speedBase;
    private Tile startTile;
    private TileGrid grid;
    private ArrayList<Checkpoint> checkpoints;
    private boolean first = true;
    private boolean chegouAoFinal = false;

    private final TipoInimigo tipo;
    private final int nivelOnda;
    private final int recompensa;

    private final ArrayList<EfeitoStatus> efeitos = new ArrayList<>();
    private boolean estaCongelado = false;

    // Acumulador de dano fracionário (correção de precisão para DOTs)
    private float damageAccumulator = 0f;

    public Inimigo(Texture texture, Tile startTile, TileGrid grid,
                   int width, int height, TipoInimigo tipo, int nivelOnda) {
        super(startTile.getX(), startTile.getY(), width, height, texture);
        this.startTile = startTile;
        this.grid = grid;
        this.tipo = tipo;
        this.nivelOnda = nivelOnda;

        // Escalonamento de dificuldade por onda
        float multVida  = 1f + (nivelOnda - 1) * 0.10f;
        float multSpeed = 1f + (nivelOnda - 1) * 0.05f;
        int bonusRec = nivelOnda - 1;

        this.healthMax = (int) (tipo.vidaBase * multVida);
        this.health = healthMax;
        this.speedBase = tipo.speedBase * multSpeed;
        this.speed = speedBase;
        this.recompensa = tipo.recompensa + bonusRec;

        this.checkpoints = Pathfinder.findPath(grid, startTile);
        this.currentCheckpoint = 0;
    }

    @Override
    public void update() {
        // Atualiza efeitos de status (DOTs, slows)
        Iterator<EfeitoStatus> it = efeitos.iterator();
        while (it.hasNext()) {
            if (!it.next().update()) it.remove();
        }

        if (first) {
            first = false;
            return;
        }

        if (checkpoints == null || checkpoints.isEmpty()) return;

        if (checkpointReached()) {
            if (currentCheckpoint + 1 >= checkpoints.size()) {
                chegouAoFinal = true;
                alive = false;
            } else {
                currentCheckpoint++;
            }
        } else {
            Checkpoint cp = checkpoints.get(currentCheckpoint);
            x += Delta() * cp.getxDirection() * speed;
            y += Delta() * cp.getyDirection() * speed;
        }
    }

    /** Testa se o inimigo alcançou o tile do checkpoint atual. */
    private boolean checkpointReached() {
        if (currentCheckpoint >= checkpoints.size()) return true;
        Checkpoint cp = checkpoints.get(currentCheckpoint);
        Tile t = cp.getTile();
        int dirX = cp.getxDirection();
        int dirY = cp.getyDirection();

        // Teste de proximidade por distância ao quadrado (eficiente)
        float dx = t.getX() - x;
        float dy = t.getY() - y;
        if (dx * dx + dy * dy < 64f) {
            x = t.getX();
            y = t.getY();
            return true;
        }

        // Teste de overshoot baseado na direção
        if (dirX > 0 && x >= t.getX()) { x = t.getX(); y = t.getY(); return true; }
        if (dirX < 0 && x <= t.getX()) { x = t.getX(); y = t.getY(); return true; }
        if (dirY > 0 && y >= t.getY()) { x = t.getX(); y = t.getY(); return true; }
        if (dirY < 0 && y <= t.getY()) { x = t.getX(); y = t.getY(); return true; }

        return false;
    }

    /**
     * Aplica dano com tipo elementar.
     * Acumula dano fracionário para garantir que DOTs funcionem corretamente.
     */
    public void takeDamage(float danoBase, TipoDano tipoDano) {
        float danoFinal = danoBase * tipoDano.multiplicadorDano;
        damageAccumulator += danoFinal;
        int danoInt = (int) damageAccumulator;
        if (danoInt > 0) {
            health -= danoInt;
            damageAccumulator -= danoInt;
        }

        // Aplica efeitos de status se o tipo tiver mecânica associada
        if (tipoDano == TipoDano.FOGO || tipoDano == TipoDano.GELO) {
            adicionarEfeito(tipoDano);
        }
        if (health <= 0) Die();
    }

    /** Sobrecarga para dano sem tipo (considerado NORMAL internamente). */
    public void takeDamage(float dmg) {
        takeDamage(dmg, TipoDano.NORMAL);
    }

    public void Die() {
        alive = false;
    }

    @Override
    public void draw() {
        float escala = (tipo == TipoInimigo.BOSS) ? 1.5f : 1f;
        float w = width * escala;
        float h = height * escala;
        float drawX = x - (w - width) * 0.5f;
        float drawY = y - (h - height) * 0.5f;

        DrawQuardTex(texture, drawX, drawY, w, h);
        drawHealthBar(drawX, drawY, w, h);
    }

    private void drawHealthBar(float drawX, float drawY, float w, float h) {
        boolean isBoss = (tipo == TipoInimigo.BOSS);
        float barW = isBoss ? 80f : 40f;
        float barH = isBoss ? 6f : 4f;
        float barX = x + (width - barW) * 0.5f;
        float barY = drawY - 10f;
        float pct = (float) health / healthMax;

        DrawQuadColor(barX, barY, barW, barH, 1f, 0f, 0f, 0.8f);
        if (isBoss) {
            DrawQuadColor(barX, barY, barW * pct, barH, 1f, 0.8f, 0f, 0.9f);
        } else {
            DrawQuadColor(barX, barY, barW * pct, barH, 0.2f, 1f, 0.2f, 0.9f);
        }
    }

    public void aplicarSlow(float factor) {
        speed = speedBase * (1f - factor);
        estaCongelado = true;
    }

    public void removerSlow() {
        speed = speedBase;
        estaCongelado = false;
    }

    /** Adiciona efeito se ainda não estiver aplicado (evita stacking). */
    public void adicionarEfeito(TipoDano tipo) {
        for (EfeitoStatus e : efeitos) {
            if (e.getTipo() == tipo) return;
        }
        efeitos.add(new EfeitoStatus(tipo, this));
    }

    // ---- Getters / Setters ----
    public float getSpeed() { return speed; }
    public void setSpeed(float s) { this.speed = s; }
    public int getHealth() { return health; }
    public void setHealth(int h) { this.health = h; }
    public int getHealthMax() { return healthMax; }
    public Tile getStartTile() { return startTile; }
    public void setStartTile(Tile t) { this.startTile = t; }
    public boolean isFirst() { return first; }
    public void setFirst(boolean f) { this.first = f; }
    public TileGrid getTileGrid() { return grid; }
    public boolean chegouAoFinal() { return chegouAoFinal; }
    public boolean isCongelado() { return estaCongelado; }
    public int getRecompensa() { return recompensa; }
    public TipoInimigo getTipo() { return tipo; }
    public int getNivelOnda() { return nivelOnda; }

    /** Retorna escala de colisão/render usada pelo tipo (BOSS é maior). */
    public float getEscala() { return (tipo == TipoInimigo.BOSS) ? 1.5f : 1f; }

    public float getCollisionX() {
        float e = getEscala();
        return x - (e - 1f) * width * 0.5f;
    }
    public float getCollisionY() {
        float e = getEscala();
        return y - (e - 1f) * height * 0.5f;
    }
    public float getCollisionW() { return width * getEscala(); }
    public float getCollisionH() { return height * getEscala(); }
}
