package data.entities;

import data.core.Entity;
import static ajudas.Artes.*;
import static ajudas.Clock.Delta;

/**
 * Particula – Efeito visual efêmero (explosões, poofs, sparks).
 *
 * Herança: estende Entity. update() e draw() sobrescritos.
 *
 * Responsabilidades:
 *  • Movimentação com velocidade e gravidade simulada.
 *  • Fade-out ao longo da vida (alpha = life / maxLife).
 *  • Shrink opcional (tamanho diminui conforme envelhece).
 *
 * Factory methods: encapsulam parâmetros visuais para cada tipo de partícula.
 */
public class Particula extends Entity {
    private float vx, vy;
    private float life, maxLife;
    private final float r, g, b;
    private final float size;
    private final boolean shrink;
    private final float gravity;

    public Particula(float x, float y, float vx, float vy, float life,
                     float r, float g, float b, float size, boolean shrink, float gravity) {
        super(x, y, size, size, null); // partículas são coloridas, sem textura
        this.vx = vx;
        this.vy = vy;
        this.life = life;
        this.maxLife = life;
        this.r = r;
        this.g = g;
        this.b = b;
        this.size = size;
        this.shrink = shrink;
        this.gravity = gravity;
    }

    @Override
    public void update() {
        x += vx * Delta();
        y += vy * Delta();
        vy += gravity * Delta();
        life -= Delta();
        if (life <= 0) alive = false;
    }

    @Override
    public void draw() {
        if (!alive) return;
        float alpha = life / maxLife;
        float s = shrink ? size * alpha : size;
        DrawQuadColor(x - s * 0.5f, y - s * 0.5f, s, s, r, g, b, alpha);
    }

    // ---- Factory Methods ----

    public static Particula morte(float x, float y) {
        float angle = (float) (Math.random() * Math.PI * 2);
        float speed = 1f + (float) Math.random() * 3f;
        float r = 0.8f + (float) Math.random() * 0.2f;
        float g = (float) Math.random() * 0.4f;
        return new Particula(x, y,
            (float) Math.cos(angle) * speed, (float) Math.sin(angle) * speed,
            0.4f + (float) Math.random() * 0.3f, r, g, 0f, 3f + (float) Math.random() * 3f, true, 0.1f);
    }

    public static Particula poofVerde(float x, float y) {
        float angle = (float) (Math.random() * Math.PI * 2);
        float speed = 0.5f + (float) Math.random() * 2f;
        return new Particula(x, y,
            (float) Math.cos(angle) * speed, (float) Math.sin(angle) * speed - 1f,
            0.3f + (float) Math.random() * 0.2f, 0.2f, 0.9f, 0.3f, 4f, true, 0.05f);
    }

    public static Particula poofDourado(float x, float y) {
        float angle = (float) (Math.random() * Math.PI * 2);
        float speed = 0.5f + (float) Math.random() * 2f;
        return new Particula(x, y,
            (float) Math.cos(angle) * speed, (float) Math.sin(angle) * speed - 1.5f,
            0.4f + (float) Math.random() * 0.3f, 1f, 0.85f, 0.1f, 3f, true, 0.08f);
    }

    public static Particula spark(float x, float y) {
        float angle = (float) (Math.random() * Math.PI * 2);
        float speed = 2f + (float) Math.random() * 4f;
        return new Particula(x, y,
            (float) Math.cos(angle) * speed, (float) Math.sin(angle) * speed,
            0.15f, 1f, 0.9f, 0.2f, 2f, true, 0f);
    }
}
