package data.entities;

import data.core.Entity;
import data.enums.TipoDano;
import org.newdawn.slick.opengl.Texture;
import ajudas.AudioManager;

import java.util.ArrayList;
import static ajudas.Artes.*;
import static ajudas.Clock.Delta;
import static org.lwjgl.opengl.GL11.*;

/**
 * Projetil – Entidade lançada por torres em direção a um alvo.
 *
 * Herança: estende Entity (posição, textura, alive).
 * Polimorfismo: update() implementa steering básico em direção ao inimigo.
 *
 * Responsabilidades:
 *  • Movimentação vetorial em direção ao alvo.
 *  • Detecção de colisão AABB contra o inimigo alvo.
 *  • Aplicação de dano elementar no impacto.
 *  • Efeito de chain lightning (ELETRICO) propagando para inimigo próximo.
 *
 * Design: O projétil é destruído após o impacto (one-shot). ChainEffects são
 * gerenciados externamente pelo PlayState para evitar vazamento entre partidas.
 */
public class Projetil extends Entity {
    private final float speed;
    private final int damage;
    private final Inimigo target;
    private final TipoDano tipoDano;

    public Projetil(Texture texture, float x, float y, int width, int height,
                    float speed, int damage, Inimigo target, TipoDano tipoDano) {
        super(x, y, width, height, texture);
        this.speed = speed;
        this.damage = damage;
        this.target = target;
        this.tipoDano = tipoDano;
    }

    /**
     * Atualiza posição e testa colisão.
     * @param todosInimigos lista completa para chain lightning.
     * @param chainList     lista mutável onde novos ChainEffects são adicionados.
     */
    public void update(ArrayList<Inimigo> todosInimigos, ArrayList<ChainEffect> chainList) {
        if (!alive || target == null || !target.isAlive()) {
            alive = false;
            return;
        }

        float dx = target.getX() - x;
        float dy = target.getY() - y;
        float distSq = dx * dx + dy * dy;

        if (colidiuComInimigo(target)) {
            alive = false;
            TipoDano tipoEfetivo = (tipoDano != null) ? tipoDano : TipoDano.NORMAL;
            target.takeDamage(damage, tipoEfetivo);
            AudioManager.play("hit", 0.9f + (float) Math.random() * 0.2f, 0.5f);

            if (tipoDano == TipoDano.ELETRICO) {
                Inimigo proximo = encontrarProximo(todosInimigos, target, 140f);
                if (proximo != null) {
                    proximo.takeDamage(damage / 2, TipoDano.ELETRICO);
                    AudioManager.play("hit", 1.3f, 0.3f);
                }
            }
        } else {
            float dist = (float) Math.sqrt(distSq);
            if (dist < 0.001f) dist = 0.001f;
            x += (dx / dist) * speed * Delta();
            y += (dy / dist) * speed * Delta();
        }
    }

    private boolean colidiuComInimigo(Inimigo inimigo) {
        float ix = inimigo.getCollisionX();
        float iy = inimigo.getCollisionY();
        float iw = inimigo.getCollisionW();
        float ih = inimigo.getCollisionH();
        return x < ix + iw && x + width > ix && y < iy + ih && y + height > iy;
    }

    private Inimigo encontrarProximo(ArrayList<Inimigo> todos, Inimigo atual, float raio) {
        Inimigo maisProximo = null;
        float menorDistSq = raio * raio;
        for (Inimigo i : todos) {
            if (i == atual || !i.isAlive()) continue;
            float dx = i.getX() - atual.getX();
            float dy = i.getY() - atual.getY();
            float dSq = dx * dx + dy * dy;
            if (dSq < menorDistSq) {
                menorDistSq = dSq;
                maisProximo = i;
            }
        }
        return maisProximo;
    }

    @Override
    public void draw() {
        if (alive) DrawQuardTex(texture, x, y, width, height);
    }

    // ============================================================
    // Inner class: ChainEffect – visual do raio chain.
    // ============================================================
    public static class ChainEffect {
        private final float x1, y1, x2, y2;
        private float life;
        private static final float MAX_LIFE = 0.15f;

        public ChainEffect(float x1, float y1, float x2, float y2) {
            this.x1 = x1; this.y1 = y1;
            this.x2 = x2; this.y2 = y2;
            this.life = MAX_LIFE;
        }

        public boolean update() {
            life -= Delta();
            return life > 0;
        }

        public void draw() {
            float alpha = life / MAX_LIFE;
            glDisable(GL_TEXTURE_2D);
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            glColor4f(1f, 0.9f, 0.2f, alpha);

            glBegin(GL_LINE_STRIP);
            int segments = 8;
            for (int i = 0; i <= segments; i++) {
                float t = (float) i / segments;
                float px = x1 + (x2 - x1) * t;
                float py = y1 + (y2 - y1) * t;
                if (i > 0 && i < segments) {
                    px += (Math.random() - 0.5) * 12;
                    py += (Math.random() - 0.5) * 12;
                }
                glVertex2f(px, py);
            }
            glEnd();

            glColor4f(1f, 1f, 1f, 1f);
            glEnable(GL_TEXTURE_2D);
        }
    }

	@Override
	public void update() {
		
		
		
	}
}
